﻿using System;
using System.Linq;
using System.Threading;
using FlaUI.Core.AutomationElements;
using FlaUIAutomation.Interfaces;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using TechTalk.SpecFlow;
using OpenQA.Selenium.Interactions;

namespace FlaUIAutomation.PageObjectsWeb
{
    class BookingInPage
    {
        private IConfig _config;

        //UIElements
        #region 
        private IWebElement TimeSlot => _config.WebDriver.FindElement(By.XPath("//button[@id='btnTimeslot1330' and not(@disabled)]"));
        private IWebElement RefreshButton => _config.WebDriver.FindElement(By.Id("btnRefresh"));
        private IWebElement VendorSearch => _config.WebDriver.FindElement(By.Id("txtVendorSearch"));
        private IWebElement VendorSearchResult(string vendorName) => _config.WebDriver.FindElement(By.Id("trwVend" + vendorName));
        private IWebElement SearchForOrder => _config.WebDriver.FindElement(By.CssSelector("input[type='search']"));
        private IWebElement OrderCheckBox(string orderNumber) => _config.WebDriver.FindElement(By.Id("chkVendOrd"+ orderNumber));
        private IWebElement AddTimeSlotButton => _config.WebDriver.FindElement(By.Id("btnTimeslotAdd"));
        private IWebElement NumberOfPalletsEntry => _config.WebDriver.FindElement(By.Id("txtSlotPallets"));
        private IWebElement UpdateButton => _config.WebDriver.FindElement(By.Id("btnUpdate"));
        private IWebElement DButton => _config.WebDriver.FindElement(By.Id("btnDel1330"));
        private IWebElement RButton => _config.WebDriver.FindElement(By.Id("btnRel1330"));
        private IWebElement FolioButton => _config.WebDriver.FindElement(By.Id("btnFolio1330"));
        private IWebElement ActualNumberOfPalletsEntry => _config.WebDriver.FindElement(By.Id("txtActualPallets"));
        private IWebElement DeliveryUpdateButton => _config.WebDriver.FindElement(By.Id("btnDeliveryUpdate"));
        private IWebElement PurchaseOrderRow(string purchaseOrder) => _config.WebDriver.FindElement(By.Id("trwOrd" + purchaseOrder));
        private IWebElement PurchaseOrderLine(string rowNumber) => _config.WebDriver.FindElement(By.XPath("//table[@id='tblRelease2']//tr/td[text()='" + rowNumber + "']"));
        private IWebElement VendorDelNo => _config.WebDriver.FindElement(By.Id("txtVendDelNo"));
        private IWebElement ReceivedQuantity => _config.WebDriver.FindElement(By.Id("txtRelQty"));
        private IWebElement NextButton => _config.WebDriver.FindElement(By.Id("btnRelNext"));
        private IWebElement PalletNumberInput => _config.WebDriver.FindElement(By.Id("txtRelPalCnt"));
        private IWebElement QuantityOnPalletInput => _config.WebDriver.FindElement(By.Id("txtRelPalQty"));
        private IWebElement BatchNumberInput => _config.WebDriver.FindElement(By.Id("txtRelBatchNo"));
        private IWebElement AddButton => _config.WebDriver.FindElement(By.Id("btnRelAdd"));
        private IWebElement DeliveryStatusDropDown => _config.WebDriver.FindElement(By.Id("selDelStatus"));
        private IWebElement BestBeforeCalendar => _config.WebDriver.FindElement(By.Id("txtRelBBD"));
        private IWebElement MonthSelectorCalendar => _config.WebDriver.FindElement(By.CssSelector(".datepicker-switch"));
        private IWebElement BackButton => _config.WebDriver.FindElement(By.Id("btnBack"));
        private IWebElement PurchaseOrderTable => _config.WebDriver.FindElement(By.Id("tblOrdSelect"));
        #endregion

        public BookingInPage(IConfig config)
        {
            _config = config;
        }

        //Methods
        #region

        public void ClickOnATime() 
        {
            WebDriverWait wait = new WebDriverWait(_config.WebDriver, TimeSpan.FromSeconds(10));
            wait.Until(ExpectedConditions.ElementToBeClickable(TimeSlot)).Click();
            new Actions(_config.WebDriver).MoveToElement(TimeSlot).SendKeys(Keys.Enter).Build().Perform();
            IJavaScriptExecutor jse = (IJavaScriptExecutor)_config.WebDriver;
            jse.ExecuteScript("arguments[0].click();", TimeSlot);
        }

        public void SearchForAVendor(string vendorName)
        {
            VendorSearch.SendKeys(vendorName + Keys.Enter);
        }

        public void ClickOnAVendor(string vendorName)
        {
            VendorSearchResult(vendorName).Click();
        }

        public void SearchForAnOrder(string order)
        {
            SearchForOrder.SendKeys(order);
            int loopCounter = 0;
                while (_config.WebDriver.FindElements(By.Id("chkVendOrd" + order)).Count == 0 && loopCounter < 15)
            {
                System.Threading.Thread.Sleep(20000);
                SearchForOrder.Clear();
                SearchForOrder.SendKeys(order);
                loopCounter++;
            }
            throw new System.Exception("Did not see expected Purchase Order");
        }

        public void SelectAnOrder(string order)
        {
            OrderCheckBox(order).Click();
        }

        public void ClickAddTimeSlotButton()
        {
            AddTimeSlotButton.Click();
        }

        public void EnterNumberOfPallets(string numberOfPallets)
        {
            NumberOfPalletsEntry.SendKeys(numberOfPallets);
        }

        public void ClickUpdate()
        {
            UpdateButton.Click();
        }

        public void ClickDButton()
        {
            DButton.Click();
        }

        public void ClickRButton()
        {
            RButton.Click();
        }

        public void ClickFolioNumber()
        {
            FolioButton.Click();
        }

        public void EnterActualNumberOfPallets(string numberOfPallets)
        {
            ActualNumberOfPalletsEntry.SendKeys(numberOfPallets);
            DeliveryUpdateButton.Click();
        }

        public void ClickOnPurchaseOrderRow(string purchaseOrder)
        {
            PurchaseOrderRow(purchaseOrder).Click();
        }

        public void ClickOnPurchaseOrderLine(string rowNumber)
        {
            PurchaseOrderLine(rowNumber).Click();
        }

        public void EnterVendorDelNoAndReceivedQty(string vendorDelNo, string receivedQty)
        {
            VendorDelNo.SendKeys(vendorDelNo);
            ReceivedQuantity.SendKeys(receivedQty);
            NextButton.Click();
        }

        public void EnterPalletNumberQtyAndBatchNo(string palletNumber, string palletQty, string batchNo)
        {
            PalletNumberInput.SendKeys(palletNumber);
            QuantityOnPalletInput.SendKeys(palletQty);
            BatchNumberInput.SendKeys(batchNo);
            AddButton.Click();
        }

        public void SelectDeliveryStatusDropDownOption(string option)
        {
            SelectElement dropDownmenu = new SelectElement(DeliveryStatusDropDown);
            dropDownmenu.SelectByText(option);
        }

        public void SetBestBeforeDate(string date)
        {
            BestBeforeCalendar.Click();
            IJavaScriptExecutor jse = (IJavaScriptExecutor)_config.WebDriver;
            jse.ExecuteScript("document.getElementById('txtRelBBD').value='27/12/2021'");

        }

        public void ClickBackButton()
        {
            BackButton.Click();
        }
        #endregion
    }
}
