﻿using System;
using System.Linq;
using System.Threading;
using FlaUI.Core.AutomationElements;
using FlaUIAutomation.Interfaces;
using NUnit.Framework;
using OpenQA.Selenium;
using TechTalk.SpecFlow;

namespace FlaUIAutomation.PageObjectsWeb
{
    public class GenericPage
    {
        private IConfig _config;

        private IWebElement StartButton => _config.WebDriver.FindElement(By.Id("btnStart"));
        private IWebElement UserIdInput => _config.WebDriver.FindElement(By.Id("txtUserID"));
        private IWebElement PasswordInput => _config.WebDriver.FindElement(By.Id("txtPass"));
        private IWebElement CustomerIdInput => _config.WebDriver.FindElement(By.XPath("//*[@id='txtCustId'] | //*[@id='txtCustID']"));
        private IWebElement LoginButton => _config.WebDriver.FindElement(By.Id("btnLogin"));
        private IWebElement ContinueButton => _config.WebDriver.FindElement(By.Id("btnContinue"));
        private IWebElement WMSWH41Button => _config.WebDriver.FindElement(By.Id("btnMenu1wh41"));


        public GenericPage(IConfig config)
        {
            _config = config;
        }


        public void EnterSearchText(string input)
        {
            StartButton.SendKeys(input);
        }

        public void NavigateToAndLogIn()
        {
            _config.WebDriver.Navigate().GoToUrl("https://wms-test.ypo.co.uk/wms/");
            StartButton.Click();
            UserIdInput.SendKeys("900900");
            ContinueButton.Click();
            PasswordInput.Click();
            PasswordInput.SendKeys("Ten10Ten10£001");
            LoginButton.Click();
        }

        internal void SwitchToTabByName(string tabname)
        {
            int count = 50;

            while (count > 0)
            {
                var handles = _config.WebDriver.WindowHandles;
                foreach (var handle in handles)
                {
                    if (_config.WebDriver.SwitchTo().Window(handle).Title.Equals(tabname))
                    {
                        return;
                    }
                }
                Thread.Sleep(300);
                count--;
            }
            throw new Exception("Could not switch to tab by tab name =>" + tabname);
        }

        internal void SearchForCustomerId(string v)
        {
            CustomerIdInput.SendKeys(v);
            CustomerIdInput.SendKeys(Keys.Enter);
        }
        internal void SearchForCustomerIdTemp(string v)
        {
            var e = _config.WebDriver.FindElement(By.Id("txtCustID"));
            e.SendKeys(v);
            e.SendKeys(Keys.Enter);
        }

        internal void AssertCustomerNameIsCorrectOnCustomerInformationPage(string customerName)
        {
            Assert.AreEqual(
                customerName,
                _config.WebDriver.FindElement(By.XPath("//tr[./th[text()='Name']]/td")).Text
                );
        }

        internal void SelectFromDropdown(string dropdownValue, string dropdownName)
        {
            // This should be generic for select type and be smart enough to decide whether select or li using `|` in xpath
            _config.WebDriver.FindElement(By.PartialLinkText(dropdownName)).Click();
            _config.WebDriver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(3);
            try
            {
                _config.WebDriver.FindElement(By.PartialLinkText(dropdownValue)).Click();
            } catch (Exception e)
            {
                _config.WebDriver.FindElement(By.PartialLinkText(dropdownName)).Click();
                _config.WebDriver.FindElement(By.PartialLinkText(dropdownValue)).Click();
            }

            _config.WebDriver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(15);

        }

        internal void AssertSalesOrderViewLineItem(Table table)
        {
            // Currently hardcoded for the first row, can be changed to do findelementS and iterated over etc etc
            var row = _config.WebDriver.FindElement(By.XPath("//table[./thead/tr[@id='trwOrderDetail']]/tbody/tr[1]"));

            // Currently assuming column positions, but they can be looked up etc etc
            Assert.AreEqual(
                        table.Rows[0][0], // Line No
                        row.FindElement(By.XPath("./td[1]")).Text
                    );

            Assert.AreEqual(
                       table.Rows[0][1], // Item No
                       row.FindElement(By.XPath("./td[2]")).Text
                   );

            Assert.AreEqual(
                       table.Rows[0][2], // Qty Requested
                       row.FindElement(By.XPath("./td[4]")).Text
                   );
            Assert.AreEqual(
                       table.Rows[0][3], // Item Status
                       row.FindElement(By.XPath("./td[8]")).Text
                   );
            Assert.AreEqual(
                       table.Rows[0][4], // Warehouse
                       row.FindElement(By.XPath("./td[9]")).Text
                   );

        }

        internal void OpenSearchResultByOrderKey(string orderid)
        {
            int count = 30;
            _config.WebDriver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(0);
            IWebElement row;

            while (count > 0)
            {
                count--;
                try
                {
                    row = _config.WebDriver.FindElement(By.XPath("//table[@id='tblOrderList']//tr/td[text()='" + orderid + "']"));
                    row.Click();
                } catch (Exception e)
                {
                    Thread.Sleep(750);
                    CustomerIdInput.SendKeys(Keys.Enter);
                }

            }
            throw new AssertionException("Could not find a row with orderid=>" + orderid);
                        
        }

        internal void ClickOnWMSWH41()
        {
            WMSWH41Button.Click();
        }

        internal void GoToItemCardPage()
        {
            _config.WebDriver.FindElement(By.XPath("//button[contains(text(), 'Item')]")).Click();
            SwitchToTabByName("WMS Item Card 41");
        }

        internal void GoToBookingInPage()
        {
            _config.WebDriver.FindElement(By.XPath("//button[contains(text(), 'Booking')]")).Click();
            SwitchToTabByName("WMS Booking In 41");
        }
    }
}