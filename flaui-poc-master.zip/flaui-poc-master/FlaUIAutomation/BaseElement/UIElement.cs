﻿using System;
using FlaUI.Core.AutomationElements;
using FlaUIAutomation.PageObjects;

namespace FlaUIAutomation.BaseElement
{

    enum IdentifierType
    {
        automationId,
        xPath,
        name,
        text
    }

    class UIElement<T> where T : AutomationElement
    {
        public T element;
        
        public void RetryClick()
        {

        }

        public UIElement(string id, IdentifierType idType = IdentifierType.xPath)
        {
            GetElement(BasePage.Window, idType, id);
        }

        private void GetElement(Window window, IdentifierType idType, string id)
        {
            switch (idType)
            {
                case IdentifierType.automationId:
                    element = window.FindFirstDescendant(cf => cf.ByAutomationId(id)).As<T>();
                    break;
                case IdentifierType.xPath:
                    var x = window.FindFirstByXPath(id);
                    element = x.As<T>();
                    //element = window.FindFirstByXPath(id).AsType<T>();
                    break;
                case IdentifierType.name:
                    element = window.FindFirstDescendant(cf => cf.ByName(id)).As<T>();
                    break;
                case IdentifierType.text:
                    element = window.FindFirstDescendant(cf => cf.ByText(id)).As<T>();
                    break;
            }
        }
    }
}
