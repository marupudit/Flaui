﻿using System;
using FlaUI.Core.AutomationElements;
using FlaUI.Core.Input;
using FlaUI.Core.Tools;
using FlaUIAutomation.BaseElement;

namespace FlaUIAutomation.PageObjects
{
    class NavHomePage : BasePage
    {

        public NavHomePage() : base()
        {
            SetWindow(WaitForWindowToAppear("Microsoft Dynamics NAV")

                );
        }

        //UIElements
        #region
        private MainMenuElement MainMenu => new MainMenuElement();
        private TextBox TextBox => new UIElement<TextBox>("Text Editor", IdentifierType.name).element;
        private TitleBar TitleBar => new UIElement<TitleBar>("TitleBar", IdentifierType.automationId).element;
        private Grid StatusBar => new UIElement<Grid>("StatusBar", IdentifierType.automationId).element;
        private TextBox Searchbar => new UIElement<TextBox>("Search", IdentifierType.name).element;
        private DataGridViewRow FirstSearchOption => new UIElement<DataGridViewRow>("Row 0", IdentifierType.name).element;

        private TreeItem SalesOrdersTreeItem => new UIElement<TreeItem>("Sales Orders", IdentifierType.name).element;
        private TreeItem RoleCentreTreeItem => new UIElement<TreeItem>("/Pane/Pane[1]/Pane[1]/Tab/Pane/Tree/TreeItem[1]", IdentifierType.xPath).element;
        private TreeItem PostedSalesShipmentTreeItem => new UIElement<TreeItem>("/Pane/Pane[1]/Pane[1]/Tab/Pane/Tree/TreeItem[21]", IdentifierType.xPath).element;
        private TreeItem VendorTreeItem => new UIElement<TreeItem>("/Pane/Pane[1]/Pane[1]/Tab/Pane/Tree/TreeItem[4]", IdentifierType.xPath).element;

        private Button TreeScrollUpButton => new UIElement<Button>("/Pane/Pane[1]/Pane[1]/Tab/Pane/Tree/ScrollBar/Button[1]", IdentifierType.xPath).element;


        private Button NewSalesOrderButton => new UIElement<Button>("/Pane/Pane[2]/Pane/Pane/Tab/TabItem/Group[1]/ListItem[3]/Button", IdentifierType.xPath).element;
        private Button SalesReturnOrderButton => new UIElement<Button>("Sales Return Order", IdentifierType.name).element;
        private Button NewButton => new UIElement<Button>("{e00eecb1-ab9d-4d87-b763-6dd25509e067}", IdentifierType.automationId).element;
        private class MainMenuElement
        {
            public Menu Main => new UIElement<Menu>("MenuBar", IdentifierType.automationId).element;

            public MenuItem File => Main.Items[0];
            public MenuItem Edit => Main.Items[1];
            public MenuItem Format => Main.Items[2];
            public MenuItem View => Main.Items[3];
            public MenuItem Help => Main.Items[4];

        }
        #endregion

        //Methods 
        #region

        public void PressNewButton()
        {
            WaitForElement(() => NewButton);
            ClickOnElement(() => NewButton);

        }

        public void SearchForWord(String searchTerm)
        {
            WaitForElement(() => Searchbar);
            ClickOnElement(() => Searchbar);
            Keyboard.Type(searchTerm);
            WaitForElement(() => FirstSearchOption);
            Keyboard.Press(FlaUI.Core.WindowsAPI.VirtualKeyShort.ENTER);
           // 
            //ClickOnElement(() => FirstSearchOption);
        }

        public void NavigateToRoleCentre()
        {
            ClickOnElement(() => TreeScrollUpButton);
            if(RoleCentreTreeItem.IsOffscreen)
            {
                Mouse.Scroll(20);
            }
            WaitForElement(() => RoleCentreTreeItem);
            ClickOnElement(() => RoleCentreTreeItem);
        }

        public void NavigateToPostedSalesShipment()
        {
            ClickOnElement(() => TreeScrollUpButton);
            if (PostedSalesShipmentTreeItem.IsOffscreen)
            {
                Mouse.Scroll(-20);
            }
            WaitForElement(() => PostedSalesShipmentTreeItem);
            ClickOnElement(() => PostedSalesShipmentTreeItem);
        }

        public NewSalesOrderPage CreateNewSalesOrder()
        {

            WaitForElement(() => SalesOrdersTreeItem);

            ClickOnElement(() => SalesOrdersTreeItem);

            WaitForElement(() => NewSalesOrderButton);

            ClickOnElement(() => NewSalesOrderButton);

            return new NewSalesOrderPage();
        }

        public void ClickNewSalesOrder()
        {
            ClickOnElement(() => NewSalesOrderButton);
        }


        public void ClickNewSalesReturnOrder()
        {
            ClickOnElement(() => SalesReturnOrderButton);
        }

        public NewSalesOrderPage NavigateToAboutPage()
        {
            MainMenu.Help.Items[2].Invoke();
            return new NewSalesOrderPage();
        }

        public void ClickVendorButton()
        {
            ClickOnElement(() => VendorTreeItem);
        }

        #endregion

        //Scrapers
        #region 

        public string GetText => TextBox.Text;

        #endregion
    }
}
