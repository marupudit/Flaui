﻿using System;
using FlaUI.Core.AutomationElements;
using FlaUI.Core.Input;
using FlaUIAutomation.BaseElement;
using NUnit.Framework;

namespace FlaUIAutomation.PageObjects
{
    class PurchaseOrderPage : NavHomePage
    {
        private string WINDOW_NAME = "Purchase Orders - Microsoft Dynamics NAV";

        public PurchaseOrderPage() : base()
        {
            SetWindow(WaitForWindowToAppear(WINDOW_NAME));
        }

        // UIElements
        #region 


        #endregion

        //Methods
        #region
        


        #endregion

        //Scrapers
        #region

        #endregion
    }

}
