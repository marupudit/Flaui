﻿using FlaUI.Core.AutomationElements;
using FlaUIAutomation.BaseElement;

namespace FlaUIAutomation.PageObjects
{
    class NoSeriesListPage: BasePage
    {
        public NoSeriesListPage(): base()
        {
            SetWindow(WaitForWindowToAppear("No. Series List"));
        }

        // UIElements
        #region 

        private Window AboutWindow => new UIElement<Window>("/Window[@Name = 'No. Series List']").element;
        private Label AboutText => new UIElement<Label>("/Window[@Name = 'About Notepad']/Text[AutomationId = '13587']").element;

        private Button OkButton => new UIElement<Button>("OK", IdentifierType.name).element;

        #endregion

        //Methods
        public NewSalesOrderPage PressOkButton()
        {
            OkButton.Click();
            return new NewSalesOrderPage();
        }
        #region

        public void CloseWindow() => AboutWindow.Close();

        #endregion

        //Scrapers
        #region

        public string GetAboutText => AboutText.Text;

        #endregion
    }

}
