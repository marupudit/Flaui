﻿using FlaUI.Core.AutomationElements;
using FlaUI.Core.Input;
using FlaUIAutomation.BaseElement;
using TechTalk.SpecFlow;
using System;
using NUnit.Framework;
using FlaUI.Core.AutomationElements.Scrolling;

namespace FlaUIAutomation.PageObjects
{
    class NewPurchaseOrderPage : BasePage
    {
        public NewPurchaseOrderPage() : base()
        {
            SetWindow(WaitForWindowToAppear("New - Purchase Order"));
        }

        // UIElements
        #region 
        private Label PurchaseOrder => new UIElement<Label>("Purchase Order", IdentifierType.name).element;
        private TextBox VendorNumber => new UIElement<TextBox>("Vendor No.", IdentifierType.name).element;
        private TextBox VendorName => new UIElement<TextBox>("/Pane/Pane[1]/Pane[2]/Pane[1]/Pane/Pane[1]/Group[2]/Edit", IdentifierType.xPath).element;
        private TextBox ExternalDocumentNumber => new UIElement<TextBox>("{00000032-42C3-BE7E-0008-0000836BD2D2}", IdentifierType.automationId).element;
        private TextBox VendorMessage => new UIElement<TextBox>("{00000032-42C3-BE81-0008-0000836BD2D2}", IdentifierType.automationId).element;
        private Label PurchaseOrderLabel => new UIElement<Label>("/Pane/Pane[1]/Pane[1]/Text", IdentifierType.xPath).element;
        private TextBox ItemType => new UIElement<TextBox>("/Pane/Pane[1]/Pane[2]/Pane[1]/Pane/Pane[1]/Group[14]/Edit", IdentifierType.xPath).element;

        //line section
        private TextBox LineType => new UIElement<TextBox>("Type", IdentifierType.name).element;
        private DataGridViewRow TypeRow(int row) => new UIElement<DataGridViewRow>("Type Row "+row, IdentifierType.name).element;
        private DataGridViewRow NumberRow(int row) => new UIElement<DataGridViewRow>("No. Row "+row, IdentifierType.name).element;
        private DataGridViewRow QuantityRow(int row) => new UIElement<DataGridViewRow>("YPO Quantity Row " + row, IdentifierType.name).element;
        private TextBox LineStatus => new UIElement<TextBox>("Line Status Row 0", IdentifierType.name).element;

        //misc
        private Button CollapseArea => new UIElement<Button>("Expand or collapse", IdentifierType.name).element;
        private TextBox Status => new UIElement<TextBox>("/Pane/Pane[1]/Pane[2]/Pane[1]/Pane/Pane[1]/Group[8]/Edit", IdentifierType.xPath).element;
        private TextBox TotalExcVAT => new UIElement<TextBox>("/Pane/Pane[1]/Pane[2]/Pane[1]/Pane/Pane[2]/Pane/Pane[2]/Pane[2]/Group[1]/Edit", IdentifierType.xPath).element;
        private TextBox TotalVAT => new UIElement<TextBox>("/Pane/Pane[1]/Pane[2]/Pane[1]/Pane/Pane[2]/Pane/Pane[2]/Pane[2]/Group[2]/Edit", IdentifierType.xPath).element;
        private TextBox TotalIncVAT => new UIElement<TextBox>("/Pane/Pane[1]/Pane[2]/Pane[1]/Pane/Pane[2]/Pane/Pane[2]/Pane[2]/Group[3]/Edit", IdentifierType.xPath).element;
        private TextBox ErrorMessage => new UIElement<TextBox>(".StaticStringControl.ResizingLabel", IdentifierType.automationId).element;

        //header
        private Button Release => new UIElement<Button>("c470e55e-d126-4920-9bb4-898a2ac3a0ff", IdentifierType.automationId).element;
        private Button Post => new UIElement<Button>("9efeb5dc-b54f-4e0f-9bfe-ad82b4c9ab28", IdentifierType.automationId).element;

        //PostOptions
        private RadioButton Receive => new UIElement<RadioButton>("{0D5D9EB3-6CEA-4b09-A2FB-7C5FB0108575}.0", IdentifierType.automationId).element;
        private Button OK => new UIElement<Button>("OK", IdentifierType.name).element;

        //ExitOptions
        private Button Yes => new UIElement<Button>("Yes", IdentifierType.name).element;
        #endregion

        //Methods

        public void EnterVendorNumber(string vendorNumber)
        {
            WaitForElement(() => VendorNumber);
            if(VendorNumber.IsOffscreen)
            {
                ClickCollapseArea();
            }
            ClickOnElement(() => VendorNumber);
            Keyboard.Type(vendorNumber);
            Keyboard.Press(FlaUI.Core.WindowsAPI.VirtualKeyShort.TAB);
        }

        public void EnterVendorMessage(string vendorMessage)
        {
            
            WaitForElement(() => VendorMessage);
            ClickOnElement(() => VendorMessage);
            Keyboard.Type(vendorMessage);
            Keyboard.Press(FlaUI.Core.WindowsAPI.VirtualKeyShort.TAB);
        }

        public void EnterExternalDocumentNumber(string externalDocumentNumber)
        {
            WaitForElement(() => ExternalDocumentNumber);
            ClickOnElement(() => ExternalDocumentNumber);
            Keyboard.Type(externalDocumentNumber);
            Keyboard.Press(FlaUI.Core.WindowsAPI.VirtualKeyShort.TAB);
        }

        public void CheckVendorName(string vendorName)
        {
    
            WaitForElement(() => VendorName);
            ClickOnElement(() => VendorName);
            var ShownVendorName = VendorName.Text;
            Assert.AreEqual(vendorName, ShownVendorName);
        }

        public void CheckItemType(string itemType)
        {
            Assert.AreEqual(itemType, ItemType.Text);
        }

        public string GetPurchaseOrderNumber()
        {
           var purchaseOrderNumber = PurchaseOrderLabel.Text;
           return purchaseOrderNumber.Substring(0, 10);
        }

        public void EnterType(string type)
        {
            WaitForElement(() => TypeRow(0));
            ClickOnElement(() => TypeRow(0));
            Keyboard.Type(type);
            Keyboard.Press(FlaUI.Core.WindowsAPI.VirtualKeyShort.TAB);
        }

        public void ClickCollapseArea()
        {
            ClickOnElement(() => CollapseArea);
        }

        public void EnterItemNumberAndQuantity(Table table)
        {

            int numberOfLines = table.Rows.Count;
            for(int iterations = 0; iterations < numberOfLines; iterations = iterations + 1)
            {
                
                var itemNumber = table.Rows[iterations]["Item number"];
                var quantity = table.Rows[iterations]["YPO quantity"];

                if (TypeRow(iterations).IsOffscreen)
                {
                    Mouse.Scroll(-10);
                }
                ClickOnElement(() => TypeRow(iterations));
                Keyboard.Press(FlaUI.Core.WindowsAPI.VirtualKeyShort.TAB);
                ClickOnElement(() => NumberRow(iterations));
                Keyboard.Type(itemNumber);
                Keyboard.Press(FlaUI.Core.WindowsAPI.VirtualKeyShort.TAB);
                ClickOnElement(() => QuantityRow(iterations));
                Keyboard.Type(quantity);
                Keyboard.Press(FlaUI.Core.WindowsAPI.VirtualKeyShort.TAB);
            }

        }

        public void ClickRelease()
        {
            ClickOnElement(() => Release);
        }

        public void CheckStatusIsReleased()
        {
            
            string status = "Released";
            Assert.AreEqual(status, Status.Text);
        }

        public void CheckLineStatus(string lineStatus)
        {
            Assert.AreEqual(lineStatus, LineStatus.Text);
        }

        public void CheckTotalExcVAT(string amount)
        {
            ClickOnElement(() => TotalExcVAT);
            Assert.AreEqual(amount, TotalExcVAT.Text);
        }
        public void CheckTotalVAT(string amount)
        {
            ClickOnElement(() => TotalVAT);
            Assert.AreEqual(amount, TotalVAT.Text);
        }

        public void CheckTotalIncVAT(string amount)
        {
            ClickOnElement(() => TotalIncVAT);
            Assert.AreEqual(amount, TotalIncVAT.Text);
        }

        public void ClickPost()
        {
            ClickOnElement(() => Post);
        }

        public void ClickReceive()
        {
            ClickOnElement(() => Receive);
            ClickOnElement(() => OK);
        }

        public void CloseWindow()
        {
            Window.Close();
            ClickOnElement(() => Yes);
        }

        public void CheckErrorMessage(string errorMessage)
        {
           Assert.AreEqual(errorMessage, ErrorMessage.Name);
        }

        public void ClickOKOnError()
        {
            ClickOnElement(() => OK);
        }
    }
}