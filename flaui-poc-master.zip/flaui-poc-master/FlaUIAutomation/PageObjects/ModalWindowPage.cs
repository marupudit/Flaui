﻿using FlaUI.Core.AutomationElements;
using FlaUIAutomation.BaseElement;
using NUnit.Framework;

namespace FlaUIAutomation.PageObjects
{
    class ModalWindowPage: BasePage
    {
        public ModalWindowPage(): base()
        {
            SetWindow(WaitForWindowToAppear("Microsoft Dynamics NAV"));
        }

        // UIElements
        #region 

        private Window AboutWindow => new UIElement<Window>("/Window[@Name = 'No. Series List']").element;

        private Label AboutText => new UIElement<Label>("/Window[@Name = 'About Notepad']/Text[AutomationId = '13587']").element;

        private Button YesButton => new UIElement<Button>("Yes", IdentifierType.name).element;
        private Button ReviewButton => new UIElement<Button>("Review", IdentifierType.name).element;
        private DataGridView BusinessRulesResults => new UIElement<DataGridView>("DataGridView", IdentifierType.name).element;

        #endregion

        //Methods
        public void PressYesButton()
        {
            WaitForElement(() => YesButton);
            YesButton.Click();
        }
        #region

        public void CloseWindow() => AboutWindow.Close();

        #endregion

        //Scrapers
        #region

        public string GetAboutText => AboutText.Text;

        #endregion
    }

}
