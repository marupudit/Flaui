﻿using FlaUI.Core;
using FlaUI.Core.AutomationElements;
using FlaUI.Core.Tools;
using FlaUI.UIA3;
using NUnit.Framework;
using System;
using System.Diagnostics;
using System.Threading;

namespace FlaUIAutomation.PageObjects
{
    class BasePage
    {
        public static Window Window { get; set; }
        public static Application App { get; set; }
        private static UIA3Automation Automation { get; set; }

        public static void LaunchApp()
        {
            Automation = new UIA3Automation();
            var si = new ProcessStartInfo();
            si.LoadUserProfile = false;
            si.UseShellExecute = false;
            si.FileName = @"C:\Program Files (x86)\Microsoft Dynamics NAV\100\RoleTailored Client\Microsoft.Dynamics.Nav.Client.exe";
            App = Application.AttachOrLaunch(si);
            Window = App.GetMainWindow(Automation);
        }

        public T WaitForElement<T>(Func<T> getter)
        {
            var retry = Retry.WhileException<T>(
                () => getter(),
                TimeSpan.FromMilliseconds(90000));

            if (!retry.Success)
            {
                Assert.Fail("Failed to get an element within a wait timeout");
            }

            return retry.Result;
        }


        public void ClickOnElement(Func<AutomationElement> element)
        {
            Retry.WhileException(
                    () => element().Click(),
                    TimeSpan.FromSeconds(90)
                );
        }


        public static void SetWindow()
        {
            Window = App.GetMainWindow(Automation, TimeSpan.FromSeconds(150));
        }

        public static void SetWindow(Window window)
        {
            Window = window;
        }

        public static Window[] GetTopLevelWindows()
        {
            return App.GetAllTopLevelWindows(Automation);
        }

        public static void KillApp()
        {
            if (App != null) { App.Kill(); }
        }

        public static Window WaitForWindowToAppear(string windowName)
        {
            int count = 50;
            Window[] windows;

            while (count > 0)
            {
                count--;
                windows = GetTopLevelWindows();
                foreach (Window window in windows)
                {
                    if (window.Name.Contains(windowName))
                    {
                        return window;
                    }
                    if (window.ModalWindows.Length > 0)
                    {
                        foreach (Window modalWindow in window.ModalWindows)
                        {
                            if (modalWindow.Name.Contains(windowName))
                            {
                                return modalWindow;
                            }
                        }
                    }
                    Thread.Sleep(500);
                }
            }

            throw new System.Exception("Did not see expected window =>" + windowName);

        }

    }
}

