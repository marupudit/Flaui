﻿using System;
using FlaUI.Core.AutomationElements;
using FlaUI.Core.Input;
using FlaUIAutomation.BaseElement;
using NUnit.Framework;

namespace FlaUIAutomation.PageObjects
{
    class IntegrationsOverviewPage : NavHomePage
    {
        private string WINDOW_NAME = "Edit - Integrations Overview";

        public IntegrationsOverviewPage() : base()
        {
            SetWindow(WaitForWindowToAppear(WINDOW_NAME));
        }

        // UIElements
        #region 
        
        private TextBox Filter => new UIElement<TextBox>("Type to filter", IdentifierType.name).element;
        private DataGridViewRow TopRow => new UIElement<DataGridViewRow>("Description Row 0", IdentifierType.name).element;

        private Button Entries => new UIElement<Button>("Entries", IdentifierType.name).element;
        #endregion

        //Methods
        #region

        public void FilterByTerm(string term)
        {
            ClickOnElement(() => Filter);
            Keyboard.Type(term);
        }

        public void HighlightTopLine()
        {
            ClickOnElement(() => TopRow);
        }
        
        public void ClickEntriesButton()
        {
            ClickOnElement(() => Entries);
        }

        public void CloseThisWindow()
        {
            Window.Close();
        }

        #endregion

        //Scrapers
        #region

        #endregion
    }

}
