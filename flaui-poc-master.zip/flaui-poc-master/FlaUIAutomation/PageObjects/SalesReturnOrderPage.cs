﻿using FlaUI.Core.AutomationElements;
using FlaUI.Core.Input;
using FlaUIAutomation.BaseElement;
using TechTalk.SpecFlow;
using System;
using NUnit.Framework;

namespace FlaUIAutomation.PageObjects
{
    class SalesReturnOrderPage : BasePage
    {
        public SalesReturnOrderPage() : base()
        {
            SetWindow(WaitForWindowToAppear("New - Sales Return Order"));
        }

        // UIElements
        #region 
        private Button LinesScrollDownButton => new UIElement<Button>("Line down", IdentifierType.name).element;
        private Button LinesScrollUpButton => new UIElement<Button>("Line up", IdentifierType.name).element;

        private TextBox CustomerNumber => new UIElement<TextBox>("/Pane/Pane[1]/Pane[2]/Pane[1]/Pane/Pane[1]/Group[1]/Edit", IdentifierType.xPath).element;
        private TextBox SalesReturnOrderLabel => new UIElement<TextBox>("label", IdentifierType.automationId).element;
        private TextBox SalesShipmentEntry => new UIElement<TextBox>("/Pane/Pane[1]/Pane[2]/Pane[1]/Pane/Pane[1]/Pane[1]/Group/Edit", IdentifierType.xPath).element;
        private DataGridView SalesShipmentTable => new UIElement<DataGridView>("DataGridView", IdentifierType.name).element;
        private TextBox SalesShipmentNumberRow(int row) => new UIElement<TextBox>("No. Row " + row, IdentifierType.name).element;
        private TextBox NumberOfParcelsEntry => new UIElement<TextBox>("/Pane/Pane[1]/Pane[2]/Pane[1]/Pane/Pane[1]/Group[4]/Edit", IdentifierType.xPath).element;
        
        private TextBox UnitPriceExcVAT(int row) => new UIElement<TextBox>("Unit Price Excl. VAT Row " +row, IdentifierType.name).element;
        private TextBox NumberRow(int row) => new UIElement<TextBox>("No. Row " + row, IdentifierType.name).element;
        private TextBox ReturnReasonRow(int row) => new UIElement<TextBox>("Return Reason Code Row " + row, IdentifierType.name).element;
        private TextBox QuantityRow(int row) => new UIElement<TextBox>("Quantity Row " + row, IdentifierType.name).element;
        private Button ReplaceRow(int row) => new UIElement<Button>("Replace Row " + row, IdentifierType.name).element;
        private Button CollectRow(int row) => new UIElement<Button>("Collect Row " + row, IdentifierType.name).element;

        private Button OK => new UIElement<Button>("OK", IdentifierType.name).element;

        private Button Yes => new UIElement<Button>("Yes", IdentifierType.name).element;

        private Button ReplacementOrderButton => new UIElement<Button>("Replacement Order", IdentifierType.name).element;
        private Button ReleaseButton => new UIElement<Button>("7a7ab259-54a2-4922-944b-149be6e75a0b", IdentifierType.automationId).element;
        private TextBox ReleaseStatus => new UIElement<TextBox>("/Pane/Pane[1]/Pane[2]/Pane[1]/Pane/Pane[1]/Group[3]/Edit", IdentifierType.xPath).element;
        private TextBox OrderTypeField => new UIElement<TextBox>("/Pane/Pane[1]/Pane[2]/Pane[1]/Pane/Pane[1]/Group[11]/Edit", IdentifierType.xPath).element;
        private Button PurchaseReturnOrder => new UIElement<Button>("Purchase Return Orders", IdentifierType.name).element;


        private TextBox TotalExcVAT => new UIElement<TextBox>("/Pane/Pane[1]/Pane[2]/Pane[1]/Pane/Pane[2]/Pane/Pane[2]/Pane[2]/Group[1]/Edit", IdentifierType.xPath).element;
        private TextBox TotalVAT => new UIElement<TextBox>("/Pane/Pane[1]/Pane[2]/Pane[1]/Pane/Pane[2]/Pane/Pane[2]/Pane[2]/Group[2]/Edit", IdentifierType.xPath).element;
        private TextBox TotalIncVAT => new UIElement<TextBox>("/Pane/Pane[1]/Pane[2]/Pane[1]/Pane/Pane[2]/Pane/Pane[2]/Pane[2]/Group[3]/Edit", IdentifierType.xPath).element;

        private Button ScrollColumnRight => new UIElement<Button>("Column right", IdentifierType.name).element;
        private Button ScrollColumnleft => new UIElement<Button>("Column left", IdentifierType.name).element;
        private Button ShowMoreFieldsInGeneralButton => new UIElement<Button>("/Pane/Pane[1]/Pane[2]/Pane[1]/Pane/Pane[1]/Hyperlink", IdentifierType.xPath).element;
        #endregion

        //Methods
        #region

        public void EnterCustomerNumber(string customerNumber)
        {
            ClickOnElement(() => CustomerNumber);
            Keyboard.Type(customerNumber);
            Keyboard.Press(FlaUI.Core.WindowsAPI.VirtualKeyShort.TAB);
        }

        public void EnterSalesShipmentNumber(string salesShipmentNumber)
        {
            ClickOnElement(() => SalesShipmentEntry);
            Keyboard.Type(salesShipmentNumber);
            Keyboard.Press(FlaUI.Core.WindowsAPI.VirtualKeyShort.TAB);
            
        }

        public string GetReturnSalesOrderNumber()
        {
            var returnSalesOrderNumber = SalesReturnOrderLabel.Text;
            return returnSalesOrderNumber.Substring(0, 11);
        }

        public void CheckItemNumberAndPrice(Table table)
        {

            int numberOfLines = table.Rows.Count + 1;
            for (int iterations = 1; iterations < numberOfLines; iterations = iterations + 1)
            {

                var itemNumber = table.Rows[iterations -1]["No."];
                var price = table.Rows[iterations -1]["Price"];


                ClickOnElement(() => NumberRow(iterations));
                Assert.AreEqual(itemNumber.ToString(), NumberRow(iterations).Text);

                Assert.AreEqual(price.ToString(), UnitPriceExcVAT(iterations).Text);

                ClickScrollDownInLinesSection();

            }

        }

        public void EnterReturnCodeAndQuantity(Table table)
        {

            ClickScrollUpInLinesSection();
            Mouse.Scroll(50);

            int numberOfLines = table.Rows.Count + 1;
            for (int iterations = 1; iterations < numberOfLines; iterations = iterations + 1)
            {
                var itemNumber = table.Rows[iterations - 1]["No."];
                var returnCode = table.Rows[iterations - 1]["ReasonCode"];
                var quantity = table.Rows[iterations - 1]["Qty"];

                ClickOnElement(() => NumberRow(iterations));

                ClickOnElement(() => ReturnReasonRow(iterations));
                Keyboard.Type(returnCode);
                Keyboard.Press(FlaUI.Core.WindowsAPI.VirtualKeyShort.TAB);
                Keyboard.Type(quantity);
                Keyboard.Press(FlaUI.Core.WindowsAPI.VirtualKeyShort.TAB);
          

                ClickScrollDownInLinesSection();
            }
            
        }

        public void CheckReleaseStatus(string status)
        {
            Assert.AreEqual(status, ReleaseStatus.Text);   
        }

        public void CheckOrderType(string orderType)
        {
            ClickOnElement(() => ShowMoreFieldsInGeneralButton);
            Assert.AreEqual(orderType, OrderTypeField.Text);
            ClickOnElement(() => ShowMoreFieldsInGeneralButton);
        }

        public void ClickScrollDownInLinesSection()
        {
            ClickOnElement(() => LinesScrollDownButton);
        }

        public void ClickScrollUpInLinesSection()
        {
            ClickOnElement(() => LinesScrollUpButton);
        }

        public void ClickRelease()
        {
            WaitForElement(() => ReleaseButton);
            ClickOnElement(() => ReleaseButton);
        }

        public void CheckTotalExcVAT(string amount)
        {
            Assert.AreEqual(amount, TotalExcVAT.Text);
        }
        public void CheckTotalVAT(string amount)
        {
            Assert.AreEqual(amount, TotalVAT.Text);
        }

        public void CheckTotalIncVAT(string amount)
        {
            Assert.AreEqual(amount, TotalIncVAT.Text);
        }

        public void SetNumberOfParcels(int numberOfParcels)
        {
            ClickOnElement(() => NumberOfParcelsEntry);
            string numberOfParcelsString = numberOfParcels.ToString();
            Keyboard.Type(numberOfParcelsString);
        }

        public void EnterReturnCodeAndQuantityAndTickReplacement(Table table)
        {

            ClickScrollUpInLinesSection();
            Mouse.Scroll(50);

            int numberOfLines = table.Rows.Count + 1;
            for (int iterations = 1; iterations < numberOfLines; iterations = iterations + 1)
            {
                var itemNumber = table.Rows[iterations - 1]["No."];
                var returnCode = table.Rows[iterations - 1]["ReasonCode"];
                var quantity = table.Rows[iterations - 1]["Qty"];
                var replacement = table.Rows[iterations - 1]["TickBoxForReplacement"];

                ClickOnElement(() => NumberRow(iterations));

                ClickOnElement(() => ReturnReasonRow(iterations));
                Keyboard.Type(returnCode);
                Keyboard.Press(FlaUI.Core.WindowsAPI.VirtualKeyShort.TAB);
                Keyboard.Type(quantity);
                Keyboard.Press(FlaUI.Core.WindowsAPI.VirtualKeyShort.TAB);
                if(replacement == "Do")
                {
                    ClickOnElement(() => ScrollColumnRight);
                    ClickOnElement(() => ScrollColumnRight);
                    ClickOnElement(() => ReplaceRow(iterations));
                    ClickOnElement(() => ScrollColumnleft);
                    ClickOnElement(() => ScrollColumnleft);
                }

                ClickScrollDownInLinesSection();
            }

        }

        public void EnterReturnCodeAndQuantityAndTickCollection(Table table)
        {

            ClickScrollUpInLinesSection();
            Mouse.Scroll(50);

            int numberOfLines = table.Rows.Count + 1;
            for (int iterations = 1; iterations < numberOfLines; iterations = iterations + 1)
            {
                var itemNumber = table.Rows[iterations - 1]["No."];
                var returnCode = table.Rows[iterations - 1]["ReasonCode"];
                var quantity = table.Rows[iterations - 1]["Qty"];
                var collection = table.Rows[iterations - 1]["TickBoxForCollection"];

                ClickOnElement(() => NumberRow(iterations));

                ClickOnElement(() => ReturnReasonRow(iterations));
                Keyboard.Type(returnCode);
                Keyboard.Press(FlaUI.Core.WindowsAPI.VirtualKeyShort.TAB);
                Keyboard.Type(quantity);
                Keyboard.Press(FlaUI.Core.WindowsAPI.VirtualKeyShort.TAB);
                if (collection == "Do")
                {
                    ClickOnElement(() => ScrollColumnRight);
                    ClickOnElement(() => ScrollColumnRight);
                    ClickOnElement(() => CollectRow(iterations));
                    ClickOnElement(() => ScrollColumnleft);
                    ClickOnElement(() => ScrollColumnleft);
                }

                ClickScrollDownInLinesSection();
            }

        }

        public void ClickReplacement()
        {
            ClickOnElement(() => ReplacementOrderButton);
        }

        public void ClickPurchaseReturnOrder()
        {
            ClickOnElement(() => PurchaseReturnOrder);
        }

        public void CloseWindow()
        {
            Window.Close();
            ClickOnElement(() => Yes);
        }

        #endregion

    }
}
