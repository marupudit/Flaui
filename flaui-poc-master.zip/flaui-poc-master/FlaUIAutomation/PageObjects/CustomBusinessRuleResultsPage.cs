﻿using FlaUI.Core.AutomationElements;
using FlaUIAutomation.BaseElement;
using NUnit.Framework;

namespace FlaUIAutomation.PageObjects
{
    class CustomBusinessRuleResultsPage: BasePage
    {
        public CustomBusinessRuleResultsPage(): base()
        {
            SetWindow(WaitForWindowToAppear("Custom Business Rule Results"));
        }

        // UIElements
        #region 

        private Window AboutWindow => new UIElement<Window>("/Window[@Name = 'No. Series List']").element;

        private Label AboutText => new UIElement<Label>("/Window[@Name = 'About Notepad']/Text[AutomationId = '13587']").element;

        private Button CloseButton => new UIElement<Button>("Close", IdentifierType.name).element;
        private Button ReviewButton => new UIElement<Button>("Review", IdentifierType.name).element;
        private DataGridView BusinessRulesResults => new UIElement<DataGridView>("DataGridView", IdentifierType.name).element;

        #endregion

        //Methods
        public NewSalesOrderPage GetRidOfBusinessRules()
        {
            Window ErrorWindow = WaitForWindowToAppear("Microsoft Dynamics NAV");

            WaitForElement(() => ErrorWindow.FindFirstDescendant(cf => cf.ByName("OK")));
            ErrorWindow.FindFirstDescendant(cf => cf.ByText("Document cannot be released until all custom business rule errors are resolved"));
            ErrorWindow.FindFirstDescendant(cf => cf.ByName("OK")).Click();

            ClickOnElement(() => ReviewButton);
            ClickOnElement(() => ReviewButton);
            CloseButton.Click();
            return new NewSalesOrderPage();
        }

        public NewSalesOrderPage AssertDuplicateMessageAndClose()
        {

            Window ErrorWindow = WaitForWindowToAppear("Microsoft Dynamics NAV");

            WaitForElement(() => ErrorWindow.FindFirstDescendant(cf => cf.ByName("OK")));
            ErrorWindow.FindFirstDescendant(cf => cf.ByText("Document cannot be released until all custom business rule errors are resolved"));
            ErrorWindow.FindFirstDescendant(cf => cf.ByName("OK")).Click();

            var resultsRow0Error = Window.FindFirstDescendant(cf => cf.ByName("Status Row 0"));
            Assert.AreEqual("Error", resultsRow0Error.AsTextBox().Text);

            var resultsRow0MessageText = Window.FindFirstDescendant(cf => cf.ByName("Message Text Row 0"));
            Assert.AreEqual("Duplicate Value", resultsRow0MessageText.AsTextBox().Text);

            WaitForElement(() => ReviewButton);
            ReviewButton.Click();

            //BusinessRulesResults.Click();
            CloseButton.Click();
            return new NewSalesOrderPage();
        }
        #region

        public void CloseWindow() => AboutWindow.Close();

        #endregion

        //Scrapers
        #region

        public string GetAboutText => AboutText.Text;

        #endregion
    }

}
