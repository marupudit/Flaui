﻿using FlaUI.Core.AutomationElements;
using FlaUI.Core.Input;
using FlaUIAutomation.BaseElement;
using TechTalk.SpecFlow;
using System.Windows.Automation;
using System;
using NUnit.Framework;
using FlaUI.UIA3.Patterns;

namespace FlaUIAutomation.PageObjects
{
    class EditPostedSalesShipmentPage : BasePage
    {

        public EditPostedSalesShipmentPage() : base()
        {
            SetWindow(WaitForWindowToAppear("Edit - Posted Sales Shipment")

                );
        }

        //UIElements
        #region

        private Button LinesScrollDownButton => new UIElement<Button>("Line down", IdentifierType.name).element;

        private TextBox CustomerName => new UIElement<TextBox>("/Pane/Pane/Pane[2]/Pane[1]/Pane/Pane[1]/Group[2]/Edit", IdentifierType.xPath).element;
        private TextBox ExternalDocumentNumber => new UIElement<TextBox>("/Pane/Pane[1]/Pane[2]/Pane[1]/Pane/Pane[1]/Group[9]/Edit", IdentifierType.xPath).element;

        private DataGridViewRow NumberRow(int row) => new UIElement<DataGridViewRow>("No. Row " + row, IdentifierType.name).element;
        private DataGridViewRow QuantityRow(int row) => new UIElement<DataGridViewRow>("Quantity Row " + row, IdentifierType.name).element;
        private DataGridViewRow QuantityCell => new UIElement<DataGridViewRow>("Quantity Row 0", IdentifierType.name).element;

        private TextBox DeliveryDateValue => new UIElement<TextBox>("/Pane/Pane[1]/Pane[2]/Pane[1]/Pane/Pane[3]/Group[1]/Edit", IdentifierType.xPath).element;
        private TextBox AgentValue => new UIElement<TextBox>("/Pane/Pane[1]/Pane[2]/Pane[1]/Pane/Pane[3]/Pane/Group[1]/Edit", IdentifierType.xPath).element;
        private TextBox PackageTrackingNumber => new UIElement<TextBox>("/Pane/Pane[1]/Pane[2]/Pane[1]/Pane/Pane[3]/Pane/Group[2]/Edit", IdentifierType.xPath).element;
        private Button ReleaseButton => new UIElement<Button>("Release", IdentifierType.name).element;

        private Button ExpandOrCollapseShippingArea => new UIElement<Button>("/Pane/Pane[1]/Pane[2]/Pane[1]/Pane/Pane[3]/ToolBar/Button[2]", IdentifierType.xPath).element;
        private Button ExpandOrCollapseGeneralArea => new UIElement<Button>("/Pane/Pane[1]/Pane[2]/Pane[1]/Pane/Pane[1]/ToolBar/Button[2]", IdentifierType.xPath).element;

        #endregion

        //Methods 
        #region


        public void CheckCustomerName(string customerName)
        {
            ClickOnElement(() => CustomerName);
            var customerNameContents = CustomerName.Text;
            Assert.AreEqual(customerName, customerNameContents);
        }

        public void CheckExternalDocNumber(string externalDocNumber)
        {
            var externalDocNumberContent = ExternalDocumentNumber.Text;
            Assert.AreEqual(externalDocNumber, externalDocNumberContent);
        }


        public void CheckQuantity(string quantity)
        {
            var quantityContents = QuantityCell.Patterns.Value.Pattern.Value;
            Assert.AreEqual(quantity, quantityContents);
        }

        public void ClickReleaseButton()
        {
            ClickOnElement(() => ReleaseButton); 
        }
        public void ClickScrollDownInLinesSection()
        {
            ClickOnElement(() => LinesScrollDownButton);
        }

        public void CheckItemNumberAndQuantity(Table table)
        {

            int numberOfLines = table.Rows.Count;
            for (int iterations = 0; iterations < numberOfLines; iterations = iterations + 1)
            {

                var itemNumber = table.Rows[iterations]["No."];
                var quantity = table.Rows[iterations]["Quantity"];


                ClickOnElement(() => NumberRow(iterations));
                Assert.AreEqual(itemNumber.ToString(), NumberRow(iterations).Patterns.Value.Pattern.Value);

                Assert.AreEqual(quantity.ToString(), QuantityRow(iterations).Patterns.Value.Pattern.Value);
                ClickScrollDownInLinesSection();

            }

        }


        public void CheckShippingSection()
        {

            ClickOnElement(() => ExpandOrCollapseGeneralArea);
            ClickOnElement(() => ExpandOrCollapseShippingArea);


        //    string agent = AgentValue.Text;
        //    if(string.IsNullOrEmpty(agent) == true)
        //    {
        //        Assert.Fail();
        //        Console.WriteLine("No Shipping Agent");
        //    }
            string date = DeliveryDateValue.Text;
            if (string.IsNullOrEmpty(date) == true)
            {
                Assert.Fail();
                Console.WriteLine("No Delivery Date Value");
            }
        //    string number = PackageTrackingNumber.Text;
        //    if (string.IsNullOrEmpty(number) == true)
        //    {
        //        Assert.Fail();
        //        Console.WriteLine("No Package Tracking Number");
        //    }

            ClickOnElement(() => ExpandOrCollapseGeneralArea);
            ClickOnElement(() => ExpandOrCollapseShippingArea);

        }
        public void CloseThisWindow()
        {
            Window.Close();
        }

        #endregion
    }
}
