﻿using System;
using FlaUI.Core.AutomationElements;
using FlaUI.Core.Input;
using FlaUI.Core.WindowsAPI;
using FlaUIAutomation.BaseElement;
using NUnit.Framework;

namespace FlaUIAutomation.PageObjects
{
    class PurchaseOrderIntEntriesPage : NavHomePage
    {
        private string WINDOW_NAME = "View -";

        public PurchaseOrderIntEntriesPage() : base()
        {
            SetWindow(WaitForWindowToAppear(WINDOW_NAME));
        }

        // UIElements
        #region 
        private MenuElement FilterMenu = new MenuElement();
        private TextBox Filter => new UIElement<TextBox>("Type to filter", IdentifierType.name).element;
        private DataGridViewRow TopRow => new UIElement<DataGridViewRow>("Description Row 0", IdentifierType.name).element;

        private Button ExpandCollapseFilterButton => new UIElement<Button>("Expand/Collapse", IdentifierType.name).element;
        private Button AddFilterButton => new UIElement<Button>("Add button", IdentifierType.name).element;
        private Button DeleteFilterButton => new UIElement<Button>("Delete button", IdentifierType.name).element;
        private Button RefreshButton => new UIElement<Button>("{d7eff514-cb9b-474c-a29d-0a821fa7555c}", IdentifierType.automationId).element;
        private Button RemoveFiltersButton => new UIElement<Button>("{339CF89F-A9D5-4ead-9EF3-339FE15C96B1}", IdentifierType.automationId).element;

        private DataGridView Table => new UIElement<DataGridView>("DataGridView", IdentifierType.name).element;

        private class MenuElement
        {
            public Menu SearchFilterMenu => new UIElement<Menu>("Scope selector for \"Type to filter\"", IdentifierType.automationId).element;

            public MenuItem EntryNo => SearchFilterMenu.Items[0];
            public MenuItem QueueID => SearchFilterMenu.Items[1];
            public MenuItem CreatedAt => SearchFilterMenu.Items[2];
            public MenuItem Status => SearchFilterMenu.Items[3];
            public MenuItem Type => SearchFilterMenu.Items[4];
            public MenuItem OrderNo => SearchFilterMenu.Items[5];

        }

        #endregion

        //Methods
        #region

        public void FilterByTerm(string term)
        {
            ClickOnElement(() => Filter);
            Keyboard.Type(term);
            Keyboard.Press(VirtualKeyShort.ENTER);
        }

        public void HighlightTopLine()
        {
            ClickOnElement(() => TopRow);
        }

        public void ExpandOrCollapseFilterOptions()
        {
            ClickOnElement(() => ExpandCollapseFilterButton);
        }

        public void RemoveFilter()
        {
            ClickOnElement(() => RemoveFiltersButton);
        }

        public void RefreshUntilTestDataAppears()
        {
            int loopCounter = 0;
            while(Table.Rows.Length == 0 && loopCounter < 15)
            {
                System.Threading.Thread.Sleep(20000);
                ClickOnElement(() => RefreshButton);
                loopCounter++;
            }
        }

        public void SelectFilterByOrderNumber()
        {
            FilterMenu.OrderNo.Items[5].Invoke();
        }

        public void CheckNumberOfLines(int numberOfLines)
        {
            var rows = Table.Rows;
            int numberOfRows = rows.Length;
            Assert.AreEqual(numberOfLines, numberOfRows);
        }
      
    }

    #endregion



    //Scrapers
    #region

    #endregion
}


