﻿using FlaUI.Core.AutomationElements;
using FlaUIAutomation.BaseElement;

namespace FlaUIAutomation.PageObjects
{
    class ViewSalesOrderPage: BasePage
    {
        public ViewSalesOrderPage(): base()
        {
            SetWindow(WaitForWindowToAppear("View - Sales Order"));
        }

        // UIElements
        #region 

        private Window ViewSalesOrderWindow => new UIElement<Window>("/Window[contains(@Name, '- Purchase Order -')]").element;
        private Label AboutText => new UIElement<Label>("/Window[@Name = 'About Notepad']/Text[AutomationId = '13587']").element;

        private Button ReleaseButton => new UIElement<Button>("Release", IdentifierType.name).element;
        private Button PostButton => new UIElement<Button>("Post...", IdentifierType.name).element;

        #endregion

        //Methods
        public void ReleaseSalesOrder()
        {
            ReleaseButton.Click();
        }

        public void PostShipAndInvoice()
        {
            PostButton.Click();
            Window infoPopup = WaitForWindowToAppear("Microsoft Dynamics NAV");
            infoPopup.FindFirstDescendant(cf => cf.ByName("Ship and Invoice"))
                .Click();

            WaitForElement(() => infoPopup.FindFirstDescendant(cf => cf.ByName("OK")));

        }
        #region

        public void CloseWindow() => ViewSalesOrderWindow.Close();

        #endregion

        //Scrapers
        #region

        public string GetAboutText => AboutText.Text;

        #endregion
    }

}
