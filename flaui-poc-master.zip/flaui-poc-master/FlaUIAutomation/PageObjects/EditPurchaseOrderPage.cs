﻿using FlaUI.Core.AutomationElements;
using FlaUI.Core.Input;
using FlaUIAutomation.BaseElement;
using NUnit.Framework;

namespace FlaUIAutomation.PageObjects
{
    class EditPurchaseOrderPage: BasePage
    {
        public EditPurchaseOrderPage(): base()
        {
            SetWindow(WaitForWindowToAppear("Edit - Purchase Order"));
        }

        // UIElements
        #region 

        private Window ViewSalesOrderWindow => new UIElement<Window>("/Window[contains(@Name, '- Purchase Order -')]").element;
        private Label AboutText => new UIElement<Label>("/Window[@Name = 'About Notepad']/Text[AutomationId = '13587']").element;

        private Button ReleaseButton => new UIElement<Button>("Release", IdentifierType.name).element;
        private Button OkButton => new UIElement<Button>("OK", IdentifierType.name).element;
        private Button PostButton => new UIElement<Button>("Post...", IdentifierType.name).element;
        private TextBox DirectUnitCostExclVatInput => new UIElement<TextBox>("Direct Unit Cost Excl. VAT Row 0", IdentifierType.name).element;

        private TextBox LineStatus => new UIElement<TextBox>("Line Status Row 0", IdentifierType.name).element;

        private TextBox Status => new UIElement<TextBox>("/Pane/Pane[1]/Pane[2]/Pane[1]/Pane/Pane[1]/Group[8]/Edit", IdentifierType.xPath).element;
        private TextBox TotalExcVAT => new UIElement<TextBox>("/Pane/Pane[1]/Pane[2]/Pane[1]/Pane/Pane[2]/Pane/Pane[2]/Pane[2]/Group[1]/Edit", IdentifierType.xPath).element;
        private TextBox TotalVAT => new UIElement<TextBox>("/Pane/Pane[1]/Pane[2]/Pane[1]/Pane/Pane[2]/Pane/Pane[2]/Pane[2]/Group[2]/Edit", IdentifierType.xPath).element;
        private TextBox TotalIncVAT => new UIElement<TextBox>("/Pane/Pane[1]/Pane[2]/Pane[1]/Pane/Pane[2]/Pane/Pane[2]/Pane[2]/Group[3]/Edit", IdentifierType.xPath).element;

        private Button Yes => new UIElement<Button>("Yes", IdentifierType.name).element;

        private Button CollapseArea => new UIElement<Button>("Expand or collapse", IdentifierType.name).element;


        #endregion

        //Methods

        public void SetDirectUnitCostExclVat(string cost)
        {
            
            WaitForElement(() => DirectUnitCostExclVatInput);
            DirectUnitCostExclVatInput.Click();
            Keyboard.Type(cost);
            Keyboard.Press(FlaUI.Core.WindowsAPI.VirtualKeyShort.TAB);
        }
        public void ReleaseSalesOrder()
        {
            ReleaseButton.Click();
        }

        public void PostShipAndInvoice()
        {
            PostButton.Click();
            Window infoPopup = WaitForWindowToAppear("Microsoft Dynamics NAV");
            infoPopup.FindFirstDescendant(cf => cf.ByName("Ship and Invoice"))
                .Click();

            WaitForElement(() => infoPopup.FindFirstDescendant(cf => cf.ByName("OK")));

        }

        public void PressOKButton()
        {
            OkButton.Click();
        }

        public void CheckLineStatus(string lineStatus)
        {
            Assert.AreEqual(lineStatus, LineStatus.Text);
        }

        public void CheckTotalExcVAT(string amount)
        {
            ClickOnElement(() => TotalExcVAT);
            Assert.AreEqual(amount, TotalExcVAT.Text);
        }
        public void CheckTotalVAT(string amount)
        {
            ClickOnElement(() => TotalVAT);
            Assert.AreEqual(amount, TotalVAT.Text);
        }

        public void CheckTotalIncVAT(string amount)
        {
            ClickOnElement(() => TotalIncVAT);
            Assert.AreEqual(amount, TotalIncVAT.Text);
        }

        public void ClosePOWindow()
        {
            Window.Close();
            ClickOnElement(() => Yes);
        }

        public void ClickCollapseArea()
        {
            ClickOnElement(() => CollapseArea);
        }

        #region

        public void CloseWindow() => ViewSalesOrderWindow.Close();

        #endregion

        //Scrapers
        #region

        public string GetAboutText => AboutText.Text;

        #endregion
    }

}
