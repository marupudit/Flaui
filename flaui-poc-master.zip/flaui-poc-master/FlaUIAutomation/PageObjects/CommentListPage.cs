﻿using FlaUI.Core.AutomationElements;
using FlaUIAutomation.BaseElement;

namespace FlaUIAutomation.PageObjects
{
    class CommentListPage : BasePage
    {

        public CommentListPage() : base()
        {
            SetWindow(WaitForWindowToAppear("Comment List -"));
        }

        //UIElements
        #region
        private Button OkButton => new UIElement<Button>("OK", IdentifierType.name).element;


        #endregion

        //Methods 
        #region

        public NewSalesOrderPage PressOkButton()
        {
            OkButton.Click();
            return new NewSalesOrderPage();
        }

        #endregion

        //Scrapers
        #region 


        #endregion
    }
}
