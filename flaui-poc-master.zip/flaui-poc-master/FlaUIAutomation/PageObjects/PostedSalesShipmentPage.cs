﻿using System;
using FlaUI.Core.AutomationElements;
using FlaUI.Core.Input;
using FlaUIAutomation.BaseElement;
using NUnit.Framework;

namespace FlaUIAutomation.PageObjects
{
    class PostedSalesShipmentPage : NavHomePage
    {
        private string WINDOW_NAME = "View - Posted Sales Shipments";

        public PostedSalesShipmentPage() : base()
        {
            SetWindow(WaitForWindowToAppear(WINDOW_NAME));
        }

        // UIElements
        #region 
        private TextBox FirstPSNumber => new UIElement<TextBox>("No. Row 0", IdentifierType.name).element;
        private Button ClearFilterButton => new UIElement<Button>("/Pane/Pane[2]/Pane/Pane/Tab/TabItem[1]/Group[10]/ListItem[2]/Button", IdentifierType.xPath).element;
        private TextBox FilterByTerm => new UIElement<TextBox>("/Pane/Pane[1]/Pane[1]/Pane[1]/Pane/Pane[1]/Pane/Pane[3]/Pane/Edit", IdentifierType.xPath).element;


        #endregion

        //Methods
        #region

        public void ClearFilter()
        {
            ClickOnElement(() => ClearFilterButton);
        }

        public void SearchForTerm(string term)
        {
            ClickOnElement(() => FilterByTerm);
            Keyboard.Type(term);
            Keyboard.Press(FlaUI.Core.WindowsAPI.VirtualKeyShort.ENTER);
        }

        public string GetPostedSalesNumber()
        {
           return FirstPSNumber.Text;
        }

        public void CloseWindow()
        {
            Window.Close();
        }


        #endregion

        //Scrapers
        #region

        #endregion
    }

}

