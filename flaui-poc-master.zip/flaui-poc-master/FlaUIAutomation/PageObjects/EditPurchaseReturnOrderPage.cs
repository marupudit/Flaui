﻿using System;
using FlaUI.Core.AutomationElements;
using FlaUI.Core.Input;
using FlaUI.Core.Tools;
using FlaUIAutomation.BaseElement;
using NUnit.Framework;

namespace FlaUIAutomation.PageObjects
{
    class EditPurchaseReturnOrderPage : BasePage
    {

        public EditPurchaseReturnOrderPage() : base()
        {
            SetWindow(

                );
        }

        //UIElements
        #region

        private TextBox VendorName => new UIElement<TextBox>("/Pane/Pane[1]/Pane[2]/Pane[1]/Pane/Pane[1]/Group[1]/Edit", IdentifierType.xPath).element;
        private TextBox ItemType => new UIElement<TextBox>("/Pane/Pane[1]/Pane[2]/Pane[1]/Pane/Pane[1]/Group[8]/Edit", IdentifierType.xPath).element;
        private TextBox Status => new UIElement<TextBox>("/Pane/Pane[1]/Pane[2]/Pane[1]/Pane/Pane[1]/Group[7]/Edit", IdentifierType.xPath).element;
        private TextBox NumberCell => new UIElement<TextBox>("No. Row 0", IdentifierType.name).element;
        private TextBox ReturnReasonCodeCell => new UIElement<TextBox>("Return Reason Code Row 0", IdentifierType.name).element;
        private TextBox QuantityCell => new UIElement<TextBox>("Quantity Row 0", IdentifierType.name).element;
        private TextBox ReturnReasonCell => new UIElement<TextBox>("Return Reason Row 0", IdentifierType.name).element;
        private Button ReleaseButton => new UIElement<Button>("Release", IdentifierType.name).element;
        #endregion

        //Methods 
        #region

        public void CheckType(string type)
        {
            var typeContents = ItemType.Text;
            Assert.AreEqual(type, typeContents);
        }

        public void CheckStatus(string status)
        {
            var statusContents = Status.Text;
            Assert.AreEqual(status, statusContents);
        }

        public void CheckVendorName(string vendorName)
        {
            var vendorNameContents = VendorName.Text;
            Assert.AreEqual(vendorName, vendorNameContents);
        }

        public void CheckNumber(string number)
        {
            var numberContents = NumberCell.Text;
            Assert.AreEqual(number, numberContents);
        }

        public void CheckReturnReasonCode(string code)
        {
            var returnReasonCodeContents = ReturnReasonCodeCell.Text;
            Assert.AreEqual(code, returnReasonCodeContents);
        }

        public void CheckReturnReason(string reason)
        {
            var returnReasonContents = ReturnReasonCell.Text;
            Assert.AreEqual(reason, returnReasonContents);
        }

        public void CheckQuantity(string quantity)
        {
            var quantityContents = QuantityCell.Text;
            Assert.AreEqual(quantity, quantityContents);
        }

        public void ClickReleaseButton()
        {
            ClickOnElement(() => ReleaseButton); 
        }



        #endregion
    }
}
