﻿using FlaUI.Core.AutomationElements;
using FlaUI.Core.Input;
using FlaUIAutomation.BaseElement;
using TechTalk.SpecFlow;
using System;
using NUnit.Framework;

namespace FlaUIAutomation.PageObjects
{
    class NewSalesOrderPage: BasePage
    {
        private string WINDOW_NAME = "New - Sales Order";

        public NewSalesOrderPage(): base()
        {
            SetWindow(WaitForWindowToAppear(WINDOW_NAME));
            

//            SetWindow(windows[1]);
            //SetWindow(); 
        }

        // UIElements
        #region 

        private Window AboutWindow => new UIElement<Window>("/Window[@Name = 'New - Sales Order']").element;
        private Label AboutText => new UIElement<Label>("/Window[@Name = 'About Notepad']/Text[AutomationId = '13587']").element;

        private Button AssistEditNo => new UIElement<Button>("/Pane/Pane[1]/Pane[2]/Pane[1]/Pane/Pane[1]/Group[1]/Button", IdentifierType.xPath).element;

        private TextBox CustomerNumberField => new UIElement<TextBox>("/Pane/Pane[1]/Pane[2]/Pane[1]/Pane/Pane[1]/Group[2]/Edit", IdentifierType.xPath).element;
        private TextBox CustomerNameField => new UIElement<TextBox>("/Pane/Pane[1]/Pane[2]/Pane[1]/Pane/Pane[1]/Group[2]/Edit", IdentifierType.xPath).element;

        private TextBox LineItemTypeField => new UIElement<TextBox>("Type Row 0", IdentifierType.name).element;

        private TextBox LineItemNoField => new UIElement<TextBox>("No. Row 0", IdentifierType.name).element;
        private TextBox QuantityField => new UIElement<TextBox>("Quantity Row 0", IdentifierType.name).element;

        private TextBox LineItemQuantityField => new UIElement<TextBox>("/Pane/Pane[1]/Pane[2]/Pane[1]/Pane/Pane[2]/Pane/Pane[1]/Table/Pane[2]/Pane/Group/Edit", IdentifierType.xPath).element;
        private TextBox ExternalDocNumber => new UIElement<TextBox>("/Pane/Pane[1]/Pane[2]/Pane[1]/Pane/Pane[1]/Group[7]/Edit", IdentifierType.xPath).element;
        private TextBox SalesOrderNo => new UIElement<TextBox>("/Pane/Pane[1]/Pane[2]/Pane[1]/Pane/Pane[1]/Group[1]/Edit", IdentifierType.xPath).element;
        private Button PostButton => new UIElement<Button>("Post...", IdentifierType.name).element;
        private Button ReleaseButton => new UIElement<Button>("/Pane/Pane[2]/Pane/Pane/Tab/TabItem[1]/Group[3]/ListItem[1]/Button", IdentifierType.xPath).element;
        private TextBox StatusField => new UIElement<TextBox>("/Pane/Pane[1]/Pane[2]/Pane[1]/Pane/Pane[1]/Group[11]/Edit", IdentifierType.xPath).element;
        private TextBox OrderTypeField => new UIElement<TextBox>("/Pane/Pane[1]/Pane[2]/Pane[1]/Pane/Pane[1]/Group[13]/Edit", IdentifierType.xPath).element;
        private TextBox OrderSourceField => new UIElement<TextBox>("/Pane/Pane[1]/Pane[2]/Pane[1]/Pane/Pane[1]/Group[10]/Edit", IdentifierType.xPath).element;
        private TextBox DeliveryTypeField => new UIElement<TextBox>("/Pane/Pane[1]/Pane[2]/Pane[1]/Pane/Pane[1]/Group[15]/Edit", IdentifierType.xPath).element;

        private Button ShipmentButton => new UIElement<Button>("Shipments", IdentifierType.name).element;
        private Menu LineOrderMenu => new UIElement<Menu>("Order", IdentifierType.name).element;
        private Menu DropShipmentMenu => new UIElement<Menu>("Drop Shipment", IdentifierType.name).element;
        private MenuItem PurchaseOrderMenuItem => new UIElement<MenuItem>("Purchase Order", IdentifierType.name).element;
        private Button OkButton => new UIElement<Button>("OK", IdentifierType.name).element;
        private Button CloseButton => new UIElement<Button>("Close", IdentifierType.name).element;

        private DataGridViewRow TypeRow(int row) => new UIElement<DataGridViewRow>("Type Row " + row, IdentifierType.name).element;
        private DataGridViewRow NumberRow(int row) => new UIElement<DataGridViewRow>("No. Row " + row, IdentifierType.name).element;
        private DataGridViewRow QuantityRow(int row) => new UIElement<DataGridViewRow>("Quantity Row " + row, IdentifierType.name).element;
        private Button LinesScrollDownButton => new UIElement<Button>("/Pane/Pane[1]/Pane[2]/Pane[1]/Pane/Pane[2]/Pane/Pane[1]/ScrollBar/Button[3]", IdentifierType.xPath).element;
        private Button CollapseArea => new UIElement<Button>("Expand or collapse", IdentifierType.name).element;

        private TextBox TotalExcVAT => new UIElement<TextBox>("/Pane/Pane[1]/Pane[2]/Pane[1]/Pane/Pane[2]/Pane/Pane[2]/Pane[2]/Group[1]/Edit", IdentifierType.xPath).element;
        private TextBox TotalVAT => new UIElement<TextBox>("/Pane/Pane[1]/Pane[2]/Pane[1]/Pane/Pane[2]/Pane/Pane[2]/Pane[2]/Group[2]/Edit", IdentifierType.xPath).element;
        private TextBox TotalIncVAT => new UIElement<TextBox>("/Pane/Pane[1]/Pane[2]/Pane[1]/Pane/Pane[2]/Pane/Pane[2]/Pane[2]/Group[3]/Edit", IdentifierType.xPath).element;

        private TextBox ErrorMessage => new UIElement<TextBox>(".StaticStringControl.ResizingLabel", IdentifierType.automationId).element;
        private Button BusinessRulesReview => new UIElement<Button>("{00012CD7-0000-0008-0008-0000836BD2D2}", IdentifierType.automationId).element;

        private RadioButton Ship => new UIElement<RadioButton>("Ship", IdentifierType.name).element;
        private Button Yes => new UIElement<Button>("Yes", IdentifierType.name).element;

        public CommentListPage EnterCustomerName(string v)
        {
            CustomerNameField.Click();
            CustomerNameField.Enter(v);
            Keyboard.Press(FlaUI.Core.WindowsAPI.VirtualKeyShort.ENTER);
            return new CommentListPage();
        }

        #endregion

        //Methods
        public NoSeriesListPage SetSalesOrderNo()
        {
            AssistEditNo.Click();
            return new NoSeriesListPage();
        }

        public void CreateLineItem(string itemNo, string quantity)
        {
            LineItemTypeField.Click();
            Keyboard.Type("Item");
            Keyboard.Press(FlaUI.Core.WindowsAPI.VirtualKeyShort.TAB);

            LineItemNoField.Click();
            Keyboard.Type(itemNo);
            Keyboard.Press(FlaUI.Core.WindowsAPI.VirtualKeyShort.TAB);

            QuantityField.Click();
            Keyboard.Type(quantity);
            Keyboard.Press(FlaUI.Core.WindowsAPI.VirtualKeyShort.TAB);

        }

        public void CreateLineItemWithRowNumber(string itemNo, string quantity, int rowNo)
        {
            if (rowNo.Equals(1))
            {
                Window.FindFirstDescendant(cf => cf.ByName("Type Row " + (rowNo - 1).ToString())).As<TextBox>().Click();            
                Keyboard.Type("Item");
                Keyboard.Press(FlaUI.Core.WindowsAPI.VirtualKeyShort.ENTER);
            }

            Window.FindFirstDescendant(cf => cf.ByName("No. Row " + (rowNo - 1).ToString())).As<TextBox>().Click();
            Keyboard.Type(itemNo);
            Keyboard.Press(FlaUI.Core.WindowsAPI.VirtualKeyShort.TAB);

            Window.FindFirstDescendant(cf => cf.ByName("Quantity Row " + (rowNo - 1).ToString())).As<TextBox>().Click();
            Keyboard.Type(quantity);
            Keyboard.Press(FlaUI.Core.WindowsAPI.VirtualKeyShort.TAB);

        }

        public void ReleaseSalesOrder()
        {
            ReleaseButton.Click();
        }
        public void SetExternalDocumentNumber(string externalDocNumber)
        {
            ExternalDocNumber.Click();
            Keyboard.Type(externalDocNumber);
            Keyboard.Press(FlaUI.Core.WindowsAPI.VirtualKeyShort.TAB);
        }
        public string RetrieveSalesOrderNumber()
        {
            var salesOrderNo = SalesOrderNo.Text;
            return salesOrderNo;
        }

        public void AssertStatusIsReleased()
        {
            WaitForElement(() => StatusField);
            if (GetStatusText != "Released")
            {
                ReleaseSalesOrder();
            }
            Assert.AreEqual("Released", GetStatusText);
        }

        public EditPurchaseOrderPage OrderDropShipmentPurchaseOrder()
        {
            WaitForElement(() => LineOrderMenu);
            LineOrderMenu.Items["Drop Shipment"].Items["Purchase Order"].Invoke();
            return new EditPurchaseOrderPage();
        }

        public void CloseWindow()
        {
            WaitForWindowToAppear(WINDOW_NAME).Close();
        }

        public void EnterCustomerNumber(string customerNumber)
        {
            WaitForElement(() => CustomerNumberField);
            ClickOnElement(() => CustomerNumberField);
            Keyboard.Type(customerNumber);
            Keyboard.Press(FlaUI.Core.WindowsAPI.VirtualKeyShort.TAB);
        }

        public void EnterItemNumberAndQuantity(Table table)
        {
            ClickOnElement(() => TypeRow(0));
            Keyboard.Type("Item");
            Keyboard.Press(FlaUI.Core.WindowsAPI.VirtualKeyShort.TAB);

            int numberOfLines = table.Rows.Count;
            for (int iterations = 0; iterations < numberOfLines; iterations = iterations + 1)
            {

                var itemNumber = table.Rows[iterations]["No."];
                var quantity = table.Rows[iterations]["Quantity"];

                ClickOnElement(() => TypeRow(iterations));
                Keyboard.Press(FlaUI.Core.WindowsAPI.VirtualKeyShort.TAB);
                ClickOnElement(() => NumberRow(iterations));
                Keyboard.Type(itemNumber);
                Keyboard.Press(FlaUI.Core.WindowsAPI.VirtualKeyShort.TAB);
                System.Threading.Thread.Sleep(2000);
                Keyboard.Press(FlaUI.Core.WindowsAPI.VirtualKeyShort.TAB);
                ClickOnElement(() => QuantityRow(iterations));
                Keyboard.Type(quantity);
                Keyboard.Press(FlaUI.Core.WindowsAPI.VirtualKeyShort.DOWN);
                ClickScrollDownInLinesSection();
            }   

        }

        public void ClickScrollDownInLinesSection()
        {
            ClickOnElement(() => LinesScrollDownButton);
        }

        public void ClickCollapseArea()
        {
            ClickOnElement(() => CollapseArea);
        }

        public void ClickPost()
        {
            ClickOnElement(() => PostButton);
        }

        public void CheckStatus(string status)
        {
            Assert.AreEqual(status, GetStatusText);
        }

        public void CheckOrderType(string orderType)
        {
            Assert.AreEqual(orderType, GetOrderType);
        }

        public void CheckOrderSource(string orderSource)
        {
            Assert.AreEqual(orderSource, GetOrderSource);
        }

        public void CheckDeliveryType(string deliveryType)
        {
            Assert.AreEqual(deliveryType, GetDeliveryType);
        }

        public void CheckTotalExcVAT(string amount)
        {
            Assert.AreEqual(amount, TotalExcVAT.Text);
        }
        public void CheckTotalVAT(string amount)
        {
            Assert.AreEqual(amount, TotalVAT.Text);
        }

        public void CheckTotalIncVAT(string amount)
        {
            Assert.AreEqual(amount, TotalIncVAT.Text);
        }


        public void CheckErrorMessage(string errorMessage)
        {
            Assert.AreEqual(errorMessage, ErrorMessage.Name);
        }

        public void SelectShip()
        {
            ClickOnElement(() => Ship);
            ClickOnElement(() => OkButton);
            SetWindow(WaitForWindowToAppear(WINDOW_NAME));
        }

        public void ClickShipment()
        {
            System.Threading.Thread.Sleep(10000);
            Keyboard.Press(FlaUI.Core.WindowsAPI.VirtualKeyShort.F5);
            System.Threading.Thread.Sleep(100);
            ClickOnElement(() => OrderTypeField);
            WaitForElement(() => ShipmentButton);
            ClickOnElement(() => ShipmentButton);
        }

        public void ClickOnCustomerName()
        {
            ClickOnElement(() => CustomerNameField);
        }

        public void CloseThisWindow()
        {
            Window.Close();
            ClickOnElement(() => Yes);
        }

        public void CreateLineItemWithRowNumberSO(string itemNo, string quantity, string rowNo)
        {
            int row = Int32.Parse(rowNo);
            if (row.Equals(1))
            {
                Window.FindFirstDescendant(cf => cf.ByName("Type Row " + (row - 1).ToString())).As<TextBox>().Click();
                Keyboard.Type("Item");
                Keyboard.Press(FlaUI.Core.WindowsAPI.VirtualKeyShort.ENTER);
            }

            Window.FindFirstDescendant(cf => cf.ByName("No. Row " + (row - 1).ToString())).As<TextBox>().Click();
            Keyboard.Type(itemNo);
            Keyboard.Press(FlaUI.Core.WindowsAPI.VirtualKeyShort.TAB);
            Keyboard.Press(FlaUI.Core.WindowsAPI.VirtualKeyShort.ENTER);

            Window.FindFirstDescendant(cf => cf.ByName("Quantity Row " + (row - 1).ToString())).As<TextBox>().Click();
            Keyboard.Type(quantity);
            Keyboard.Press(FlaUI.Core.WindowsAPI.VirtualKeyShort.TAB);

        }

        public NewSalesOrderPage SubstitutionChoose()
        {
            Window SubstitutionWindow = WaitForWindowToAppear("View - Availability check - 703460 ∙ T.E - Metallic Marker Silver Pk 10");

            WaitForElement(() => SubstitutionWindow.FindFirstDescendant(cf => cf.ByName("Select Substitute")));
            SubstitutionWindow.FindFirstDescendant(cf => cf.ByName("Select Substitute")).Click();

            Keyboard.Press(FlaUI.Core.WindowsAPI.VirtualKeyShort.ENTER);
            return new NewSalesOrderPage();
        }
        #region


        #endregion

        //Scrapers
        #region

        public string GetAboutText => AboutText.Text;

        public string GetOrderType => OrderTypeField.Text;

        public string GetStatusText => StatusField.Text;

        public string GetOrderSource => OrderSourceField.Text;

        public string GetDeliveryType => DeliveryTypeField.Text;

        #endregion
    }

}
