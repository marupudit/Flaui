﻿using System;
using FlaUI.Core.AutomationElements;
using FlaUI.Core.Input;
using FlaUI.Core.WindowsAPI;
using FlaUIAutomation.BaseElement;
using NUnit.Framework;
using FlaUI.Core.Tools;


namespace FlaUIAutomation.PageObjects
{
    class HomePostedSalesShipmentPage : BasePage
    {

        public HomePostedSalesShipmentPage() : base()
        {
            SetWindow(

                );
        }

        //UIElements
        #region

        private MenuElement FilterMenu = new MenuElement();
        private TextBox PopUpMessage => new UIElement<TextBox>(".StaticStringControl.ResizingLabel", IdentifierType.automationId).element;
        private Button Yes => new UIElement<Button>("Yes", IdentifierType.name).element;
        private TextBox FilterShipments => new UIElement<TextBox>("Type to filter", IdentifierType.name).element;
        private Button CreateReturnOrderButton => new UIElement<Button>("Create Return Order", IdentifierType.name).element;

        private TextBox TopRowNumber => new UIElement<TextBox>("No. Row 0", IdentifierType.name).element;
        private TextBox TopRowCustomerName => new UIElement<TextBox>("Sell-to Customer Name Row 0", IdentifierType.name).element;
        private TextBox TopRowExternalDocNumber => new UIElement<TextBox>("External Document No. Row 0", IdentifierType.name).element;
        private class MenuElement
        {
            public Menu SearchFilterMenu => new UIElement<Menu>("Scope selector for \"Type to filter\"", IdentifierType.automationId).element;

            public MenuItem LotNo => SearchFilterMenu.Items[0];
            public MenuItem Date => SearchFilterMenu.Items[1];
            public MenuItem ItemNo => SearchFilterMenu.Items[2];
            public MenuItem DocType => SearchFilterMenu.Items[3];
            public MenuItem DocNo => SearchFilterMenu.Items[4];
            public MenuItem OrderNo => SearchFilterMenu.Items[5];

        }
        #endregion

        //Methods 
        #region

        public void CheckPopUpMessage(string popUpMessage)
        {
            Assert.AreEqual(popUpMessage, PopUpMessage.Name);
        }

        public void ClickYes()
        {
            ClickOnElement(() => Yes);
        }

        public void ClickCreateReturnOrder()
        {
            ClickOnElement(() => CreateReturnOrderButton);
        }

        public void SelectFilterByOrderNumber()
        {
            FilterMenu.OrderNo.Items[5].Invoke();
        }
        public void FilterByTerm(string term)
        {
            ClickOnElement(() => FilterShipments);
            Keyboard.Type(term);
            Keyboard.Press(VirtualKeyShort.ENTER);
        }

        public void ClickOnTopRow()
        {
            ClickOnElement(() => TopRowNumber);
            Keyboard.Press(VirtualKeyShort.ENTER);
        }

        public void CheckCustomerName(string customerName)
        {
            Assert.AreEqual(customerName, TopRowCustomerName.Text);
        }

        public void CheckExternalDocNumber(string externalDocNumber)
        {
            Assert.AreEqual(externalDocNumber, TopRowExternalDocNumber.Text);
        }

        #endregion
    }
}
