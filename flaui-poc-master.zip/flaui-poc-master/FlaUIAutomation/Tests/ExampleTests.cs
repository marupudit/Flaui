﻿
using FlaUIAutomation.PageObjects;
using System;
using FlaUI.Core.Tools;
using NUnit.Framework;
using FlaUIAutomation.Tests;

namespace FlaUIAutomation
{

    public class ExampleTests : BaseTest
    {
        [Test]
        public void NewStockItemSalesOrder()
        {
            var navHomePage = new NavHomePage();
            NewSalesOrderPage createSalesOrderPage;
            NoSeriesListPage noSeriesListPage;
            

            createSalesOrderPage = navHomePage.CreateNewSalesOrder();
            Retry.WhileNull(() => new NewSalesOrderPage(), TimeSpan.FromSeconds(30));

            noSeriesListPage = createSalesOrderPage.SetSalesOrderNo();
            createSalesOrderPage = noSeriesListPage.PressOkButton();
            createSalesOrderPage.SetExternalDocumentNumber(Guid.NewGuid().ToString());

            CommentListPage commentListPage = createSalesOrderPage.EnterCustomerName("000000");
            createSalesOrderPage = commentListPage.PressOkButton();
            createSalesOrderPage.CreateLineItem("72257X", "1");
            createSalesOrderPage.ReleaseSalesOrder();
            CustomBusinessRuleResultsPage customBusinessRuleResultsPage = new CustomBusinessRuleResultsPage();
            customBusinessRuleResultsPage.AssertDuplicateMessageAndClose();
            createSalesOrderPage.AssertStatusIsReleased();

            Console.WriteLine("Finished");            
        }

        [Test]
        public void NewDirectItemSalesOrderWithPurchaseOrder()
        {
            var navHomePage = new NavHomePage();
            NewSalesOrderPage newSalesOrderPage;
            NoSeriesListPage noSeriesListPage;

            newSalesOrderPage = navHomePage.CreateNewSalesOrder();
            Retry.WhileNull(() => new NewSalesOrderPage(), TimeSpan.FromSeconds(30));

            noSeriesListPage = newSalesOrderPage.SetSalesOrderNo();
            newSalesOrderPage = noSeriesListPage.PressOkButton();
            newSalesOrderPage.SetExternalDocumentNumber(Guid.NewGuid().ToString());

            CommentListPage commentListPage = newSalesOrderPage.EnterCustomerName("000000");
            newSalesOrderPage = commentListPage.PressOkButton();
            newSalesOrderPage.CreateLineItem("D17338", "1");
            newSalesOrderPage.ReleaseSalesOrder();

            CustomBusinessRuleResultsPage customBusinessRuleResultsPage = new CustomBusinessRuleResultsPage();
            customBusinessRuleResultsPage.AssertDuplicateMessageAndClose();
            newSalesOrderPage.AssertStatusIsReleased();
            newSalesOrderPage = new NewSalesOrderPage();

            EditPurchaseOrderPage editPurchaseOrderPage = newSalesOrderPage.OrderDropShipmentPurchaseOrder();
            editPurchaseOrderPage.SetDirectUnitCostExclVat("1");
            editPurchaseOrderPage.ReleaseSalesOrder();
            editPurchaseOrderPage.PressOKButton();

            ModalWindowPage modalWindowPage = new ModalWindowPage();
            modalWindowPage.PressYesButton();

            newSalesOrderPage.CloseWindow();

            modalWindowPage = new ModalWindowPage();
            modalWindowPage.PressYesButton();


            Console.WriteLine("Finished");
        }

        [Test]
        public void NAVDirectStockItemSalesOrderWithPurchaseOrder()
        {
            var navHomePage = new NavHomePage();

            NewSalesOrderPage newSalesOrderPage;
            NoSeriesListPage noSeriesListPage;

            newSalesOrderPage = navHomePage.CreateNewSalesOrder();
            Retry.WhileNull(() => new NewSalesOrderPage(), TimeSpan.FromSeconds(30));

            noSeriesListPage = newSalesOrderPage.SetSalesOrderNo();
            newSalesOrderPage = noSeriesListPage.PressOkButton();
            newSalesOrderPage.SetExternalDocumentNumber(Guid.NewGuid().ToString());

            CommentListPage commentListPage = newSalesOrderPage.EnterCustomerName("000000");
            newSalesOrderPage = commentListPage.PressOkButton();
            newSalesOrderPage.CreateLineItem("72257X", "1");
            newSalesOrderPage.CreateLineItemWithRowNumber("D17338", "1", 2);
            newSalesOrderPage.ReleaseSalesOrder();

            CustomBusinessRuleResultsPage customBusinessRuleResultsPage = new CustomBusinessRuleResultsPage();
            customBusinessRuleResultsPage.AssertDuplicateMessageAndClose();
            newSalesOrderPage.AssertStatusIsReleased();
            newSalesOrderPage = new NewSalesOrderPage();

            EditPurchaseOrderPage editPurchaseOrderPage = newSalesOrderPage.OrderDropShipmentPurchaseOrder();
            editPurchaseOrderPage.SetDirectUnitCostExclVat("1");
            editPurchaseOrderPage.ReleaseSalesOrder();
            editPurchaseOrderPage.PressOKButton();

            ModalWindowPage modalWindowPage = new ModalWindowPage();
            modalWindowPage.PressYesButton();

            newSalesOrderPage.CloseWindow();

            modalWindowPage = new ModalWindowPage();
            modalWindowPage.PressYesButton();


            Console.WriteLine("Finished");
        }


    }
}
