﻿using FlaUIAutomation.PageObjects;
using TechTalk.SpecFlow;


namespace FlaUIAutomation.Steps
{
    [Binding]
    public class StepDefinitionsPO
    {
        
        private readonly ScenarioContext _scenarioContext;

        public StepDefinitionsPO(ScenarioContext scenarioContext)
        {
            _scenarioContext = scenarioContext;
        }

        [AfterScenario]
        public void AfterScenario()
        {
           BasePage.KillApp();
        }

        [Given(@"I am on the NAV homepage")]

        public void IamOnTheHomePage()
        {

            BasePage.LaunchApp();
            BasePage.SetWindow();

        }

        [When(@"I search Purchase Order in the top right searchbar")] 
        
        public void ISearchPurchaseOrderInTheTopRightSearchbar()
            {
            var navHomePage = new NavHomePage();
            navHomePage.SearchForWord("Purchase Order");
            }

        [When(@"select New in the header")]

        public void SelectNewInTheHeader()
        {
            var navHomePage = new NavHomePage();
            navHomePage.PressNewButton();
        }

        [When(@"I enter, Vendor number, Vendor message and External Document number")]
        public void IEnterVendorNumberVendorMessageAndExternalDocumentNumber(Table table)
        {

            var vendorNumber = table.Rows[0]["Vendor number"];


            var vendorMessage = table.Rows[0]["Vendor message"];

            var externalDocumentNumber = table.Rows[0]["External Document number"];


            var newPurchaseOrderPage = new NewPurchaseOrderPage();
            newPurchaseOrderPage.EnterVendorNumber(vendorNumber);
            newPurchaseOrderPage.EnterVendorMessage(vendorMessage);
            newPurchaseOrderPage.EnterExternalDocumentNumber(externalDocumentNumber);

        }

        [Then(@"it should automatically populate the vendor name with ""(.*)""")]
        public void ThenItShouldAutomaticallyPopulateTheVendorNameWith(string vendorName)
        {
            var newPurchaseOrderPage = new NewPurchaseOrderPage();
            newPurchaseOrderPage.CheckVendorName(vendorName);
        }

        [When(@"I note down the YPO order number")]
        public void WhenINoteDownTheYPOOrderNumber()
        {
            var newPurchaseOrderPage = new NewPurchaseOrderPage();
            newPurchaseOrderPage.GetPurchaseOrderNumber();
            _scenarioContext.Add("purchaseOrderNumber", newPurchaseOrderPage.GetPurchaseOrderNumber());
        }

        [When(@"select type in the lines section")]
        public void SelectTypeInTheLinesSection()
        {
            var newPurchaseOrderPage = new NewPurchaseOrderPage();
            newPurchaseOrderPage.ClickCollapseArea();
            newPurchaseOrderPage.EnterType("Item");
        }
        

        [When(@"I enter each item number and YPO quantity")]
        public void WhenIEnterEachItemNumberAndYPOQuantity(Table table)
        {
            var newPurchaseOrderPage = new NewPurchaseOrderPage();
            newPurchaseOrderPage.EnterItemNumberAndQuantity(table);

        }

        [Then(@"I should see an error box advising ""(.*)""")]
        public void ThenIShouldSeeAnErrorBoxAdvising(string errorMessage)
        {
            var newPurchaseOrderPage = new NewPurchaseOrderPage();
            newPurchaseOrderPage.CheckErrorMessage(errorMessage);
            newPurchaseOrderPage.ClickOKOnError();
        }

        [Then(@"there are ""(.*)"" lines shown on the order")]
        public void ThenThereAreLinesShownOnTheOrder(string p0)
        {
            
        }

        [When(@"I select Release from the Home header")]
        public void WhenISelectReleaseFromTheHomeHeader()
        {
            var newPurchaseOrderPage = new NewPurchaseOrderPage();
            newPurchaseOrderPage.ClickRelease();
        }

        [Then(@"the Status should change to Released in the General section\.")]
        public void ThenTheStatusShouldChangeToReleasedInTheGeneralSection_()
        {
            var newPurchaseOrderPage = new NewPurchaseOrderPage();
            newPurchaseOrderPage.CheckStatusIsReleased();
        }

        [Then(@"Item Type should populate as Stock")]
        public void ThenItemTypeShouldPopulateAsStock()
        {
            var newPurchaseOrderPage = new NewPurchaseOrderPage();
            newPurchaseOrderPage.CheckItemType("Stock");
        }

        [Then(@"Line Status should change to Submitted to Vendor")]
        public void ThenLineStatusShouldChangeToSubmittedToVendor()
        {
            var newPurchaseOrderPage = new NewPurchaseOrderPage();
            newPurchaseOrderPage.CheckLineStatus("Submitted to Vendor");
            
        }

        [Then(@"Total Excl\. VAT should be showing ""(.*)""")]
        public void ThenTotalExcl_VATShouldBeShowing(string total)
        {
            var newPurchaseOrderPage = new NewPurchaseOrderPage();
            newPurchaseOrderPage.CheckTotalExcVAT(total);
        }

        [Then(@"Total VAT should be showing ""(.*)""")]
        public void ThenTotalVATShouldBeShowing(string total)
        {
            var newPurchaseOrderPage = new NewPurchaseOrderPage();
            newPurchaseOrderPage.CheckTotalVAT(total);
        }

        [Then(@"Total Inc\. VAT should be showing ""(.*)""")]
        public void ThenTotalInc_VATShouldBeShowing(string total)
        {
            var newPurchaseOrderPage = new NewPurchaseOrderPage();
            newPurchaseOrderPage.CheckTotalIncVAT(total);
        }

        [When(@"I select Post in the header")]
        public void WhenISelectPostInTheHeader()
        {
            var newPurchaseOrderPage = new NewPurchaseOrderPage();
            newPurchaseOrderPage.ClickPost();
        }

        [When(@"I select the option for Receive")]
        public void WhenISelectTheOptionForReceive()
        {
            var newPurchaseOrderPage = new NewPurchaseOrderPage();
            newPurchaseOrderPage.ClickReceive();
        }

        [When(@"close the order screen")]
        public void WhenCloseTheOrderScreen()
        {
            var newPurchaseOrderPage = new NewPurchaseOrderPage();
            newPurchaseOrderPage.ClickCollapseArea();
            newPurchaseOrderPage.CloseWindow();
        }

        [When(@"navigate to the role centre screen")]
        public void WhenNavigateToTheRoleCentreScreen()
        {
            var purchaseOrderPage = new PurchaseOrderPage();
            purchaseOrderPage.NavigateToRoleCentre();

        }

        [When(@"search for Integrations Overview in the top right-hand search box")]
        public void WhenSearchForIntegrationsOverviewInTheTopRight_HandSearchBox()
        {
            var navHomePage = new NavHomePage();
            navHomePage.SearchForWord("Integrations Overview");
        }

        [When(@"highlight the line for WMS Purchase Order Line Data")]
        public void WhenHighlightTheLineForWMSPurchaseOrderLineData()
        {
            var integrationsOverviewPage = new IntegrationsOverviewPage();
            integrationsOverviewPage.FilterByTerm("WMS Purchase Order Line data");
            integrationsOverviewPage.HighlightTopLine();
        }

        [When(@"select entries from the Home header")]
        public void WhenSelectEntriesFromTheHomeHeader()
        {
            var integrationsOverviewPage = new IntegrationsOverviewPage();
            integrationsOverviewPage.ClickEntriesButton();
        }

        [When(@"clear the filters if any are applied")]
        public void WhenClearTheFiltersIfAnyAreApplied()
        {
            var purchaseOrderIntEntriesPage = new PurchaseOrderIntEntriesPage();
            purchaseOrderIntEntriesPage.RemoveFilter();
        }

        [When(@"Enter the order number that you noted down earlier in the search box")]
        public void WhenEnterTheOrderNumberThatYouNotedDownEarlierInTheSearchBox()
        {
            var purchaseOrderIntEntriesPage = new PurchaseOrderIntEntriesPage();
            var value = _scenarioContext["purchaseOrderNumber"];
            string purchaseOrderNumber = value.ToString();
            purchaseOrderIntEntriesPage.FilterByTerm(purchaseOrderNumber);
            purchaseOrderIntEntriesPage.RefreshUntilTestDataAppears();
        }

        [When(@"Change the dropdown filter next to it to Order Number in Purchase Order Line")]
        public void WhenChangeTheDropdownFilterNextToItToOrderNumberInPurchaseOrderLine()
        {
           // var purchaseOrderIntEntriesPage = new PurchaseOrderIntEntriesPage();
            //purchaseOrderIntEntriesPage.SelectFilterByOrderNumber();
        }

        [When(@"Change the dropdown filter next to it to Order Number")]
        public void WhenChangeTheDropdownFilterNextToItToOrderNumber()
        {

        }

        [Then(@"this should then show the same number of lines that have been processed on the sales order that was just created ""(.*)""")]
        public void ThenThisShouldThenShowTheSameNumberOfLinesThatHaveBeenProcessedOnTheSalesOrderThatWasJustCreated(string p0)
        {
            var purchaseOrderIntEntriesPage = new PurchaseOrderIntEntriesPage();
            purchaseOrderIntEntriesPage.CheckNumberOfLines(5);
        }

        [Then(@"the line numbers match the sales order lines numbers that was just created")]
        public void ThenTheLineNumbersMatchTheSalesOrderLinesNumbersThatWasJustCreated()
        {
            
        }

        [When(@"I reopen NAV")]
        public void WhenIReopenNAV()
        {
            BasePage.LaunchApp();
            BasePage.SetWindow();
        }


        [When(@"Highlight the line for NAV Purchase Receipts")]
        public void WhenHighlightTheLineForNAVPurchaseReceipts()
        {
            var integrationsOverviewPage = new IntegrationsOverviewPage();
            integrationsOverviewPage.FilterByTerm("NAV Purchase Receipts");
            integrationsOverviewPage.HighlightTopLine();
        }

        [When(@"Select View in the header")]
        public void WhenSelectViewInTheHeader()
        {
            var editPurchaseReceiptIntEntriesPage = new EditPurchaseReceiptIntEntriesPage();
            editPurchaseReceiptIntEntriesPage.ClickViewButton();
        }

        [When(@"I go down to the Lines section")]
        public void WhenIGoDownToTheLinesSection()
        {
          
        }

        [When(@"I Search for ""(.*)"" in the top right-hand side search box")]
        public void WhenISearchForInTheTopRight_HandSideSearchBox(string searchTerm)
        {
            var navHomePage = new NavHomePage();
            navHomePage.SearchForWord(searchTerm);
        }

        [When(@"Search the PO number noted down earlier")]
        public void WhenSearchThePONumberNotedDownEarlier()
        {
            var pendingLedgerEntriesPage = new PendingLedgerEntriesPage();
            var value = _scenarioContext["purchaseOrderNumber"];
            string PONumber = value.ToString();
            pendingLedgerEntriesPage.SelectFilterByOrderNumber();
            pendingLedgerEntriesPage.FilterByTerm(PONumber);
        }

        [When(@"change the dropdown to Order No\.")]
        public void WhenChangeTheDropdownToOrderNo_()
        {
            var pendingLedgerEntriesPage = new PendingLedgerEntriesPage();
            pendingLedgerEntriesPage.SelectFilterByOrderNumber();
        }

        [When(@"Highlight the line and select Create Return Order from the header")]
        public void WhenHighlightTheLineAndSelectCreateReturnOrderFromTheHeader()
        {
            var pendingLedgerEntriesPage = new PendingLedgerEntriesPage();
            pendingLedgerEntriesPage.ClickCreateReturnOrder();
        }

        [Then(@"On the next screen the order number should have a tick in the Include tick boxes")]
        public void ThenOnTheNextScreenTheOrderNumberShouldHaveATickInTheIncludeTickBoxes()
        {

        }

        [Then(@"there should be a pop-up box asking, ""(.*)""")]
        public void ThenThereShouldBeAPop_UpBoxAsking(string popUp)
        {
            var pendingLedgerEntriesPage = new PendingLedgerEntriesPage();
            pendingLedgerEntriesPage.CheckPopUpMessage(popUp);
        }

        [When(@"I Select Yes")]
        public void WhenISelectYes()
        {
            var pendingLedgerEntriesPage = new PendingLedgerEntriesPage();
            pendingLedgerEntriesPage.ClickYes();
        }

        [Then(@"the Purchase Return Order should open")]
        public void ThenThenThePurchaseReturnOrderShouldOpen()
        {
            
        }

        [Then(@"in the general section the Vendor should be populated with ""(.*)""")]
        public void ThenInTheGeneralSectionTheVendorShouldBePopulatedWith(string vendor)
        {
            var editPurchaseReturnOrderPage = new EditPurchaseReturnOrderPage();
            editPurchaseReturnOrderPage.CheckVendorName(vendor);
        }

        [Then(@"Status should be ""(.*)""")]
        public void ThenStatusShouldBe(string status)
        {
            var editPurchaseReturnOrderPage = new EditPurchaseReturnOrderPage();
            editPurchaseReturnOrderPage.CheckStatus(status);
        }

        [Then(@"Item Type should be ""(.*)""")]
        public void ThenItemTypeShouldBe(string type)
        {
            var editPurchaseReturnOrderPage = new EditPurchaseReturnOrderPage();
            editPurchaseReturnOrderPage.CheckType(type);
        }

        [Then(@"in the lines section No\. should be populated with ""(.*)""")]
        public void ThenInTheLinesSectionNo_ShouldBePopulatedWith(string number)
        {
            var editPurchaseReturnOrderPage = new EditPurchaseReturnOrderPage();
            editPurchaseReturnOrderPage.CheckNumber(number);
        }

        [Then(@"Return Reason Code should be populated with ""(.*)""")]
        public void ThenReturnReasonCodeShouldBePopulatedWith(string returnCode)
        {
            var editPurchaseReturnOrderPage = new EditPurchaseReturnOrderPage();
            editPurchaseReturnOrderPage.CheckReturnReasonCode(returnCode);
        }

        [Then(@"Return Reason should be populated with ""(.*)""")]
        public void ThenReturnReasonShouldBePopulatedWith(string returnReason)
        {
            var editPurchaseReturnOrderPage = new EditPurchaseReturnOrderPage();
            editPurchaseReturnOrderPage.CheckReturnReason(returnReason);
        }

        [Then(@"Quantity should be populated with ""(.*)""")]
        public void ThenQuantityShouldBePopulatedWith(string quantity)
        {
            var editPurchaseReturnOrderPage = new EditPurchaseReturnOrderPage();
            editPurchaseReturnOrderPage.CheckQuantity(quantity);
        }


        [When(@"I Select Release from the header and close the screen")]
        public void WhenISelectReleaseFromTheHeaderAndCloseTheScreen()
        {
            var editPurchaseReturnOrderPage = new EditPurchaseReturnOrderPage();
            editPurchaseReturnOrderPage.ClickReleaseButton();
        }


        [When(@"Highlight the line for WMS Purchase Return Order Line Data")]
        public void WhenHighlightTheLineForWMSPurchaseReturnOrderLineData()
        {
            var integrationsOverviewPage = new IntegrationsOverviewPage();
            integrationsOverviewPage.FilterByTerm("WMS Purchase Return Order Line data");
            integrationsOverviewPage.HighlightTopLine();
        }


        [When(@"Go down to the Lines section")]
        public void WhenGoDownToTheLinesSection()
        {
           
        }
    }
}
