﻿using FlaUIAutomation.PageObjects;
using TechTalk.SpecFlow;
using FlaUI.Core.Input;
using FlaUI.Core.WindowsAPI;


namespace FlaUIAutomation.Steps
{
    [Binding]
    class StepDefinitionsSO
    {
        private readonly ScenarioContext _scenarioContext;

        public StepDefinitionsSO(ScenarioContext scenarioContext)
        {
            _scenarioContext = scenarioContext;
        }

        [AfterScenario]
        public void AfterScenario()
        {
            BasePage.KillApp();
        }

        [Given(@"I have NAV open")]

        public void IHaveNAVOpen()
        {

            BasePage.LaunchApp();
            BasePage.SetWindow();

        }

        [Given(@"I have the sales order screen open")]
        public void GivenIHaveTheSalesOrderScreenOpen()
        {
            var navHomePage = new NavHomePage();
            navHomePage.ClickNewSalesOrder();
        }

        [When(@"I generate a sales order for customer ""(.*)"" with order number ""(.*)""")]
        public void WhenIHaveGenerateASalesOrderForCustomerWithOrderNumber(string customerNumber, string externalDocNumber, Table table)
        {
            var newSalesOrderPage = new NewSalesOrderPage();
  
            newSalesOrderPage.EnterCustomerNumber(customerNumber);
            newSalesOrderPage.SetExternalDocumentNumber(externalDocNumber);
            newSalesOrderPage.ClickCollapseArea();
            newSalesOrderPage.EnterItemNumberAndQuantity(table);
        }

        [When(@"make a note of the customer's YPO number")]
        public void WhenMakeANoteOfTheCustomersYPONumber()
        {
            var newSalesOrderPage = new NewSalesOrderPage();
            newSalesOrderPage.ClickCollapseArea();
            _scenarioContext.Add("salesOrderNumber", newSalesOrderPage.RetrieveSalesOrderNumber());  
        }

        [When(@"select release from the Home header")]
        public void WhenSelectReleaseFromTheHomeHeader()
        {
            var newSalesOrderPage = new NewSalesOrderPage();
            newSalesOrderPage.ReleaseSalesOrder();
            //custom business rules about duplicated orders dealt with below not sure if this should exist
            var customBusinessRuleResultsPage = new CustomBusinessRuleResultsPage();
            customBusinessRuleResultsPage.GetRidOfBusinessRules();
            newSalesOrderPage.ReleaseSalesOrder();
        }

        [When(@"select release from the Home header expecting business rules")]
        public void WhenSelectReleaseFromTheHomeHeaderBusinessRules()
        {
            var newSalesOrderPage = new NewSalesOrderPage();
            newSalesOrderPage.ReleaseSalesOrder();
            
        }

        [When(@"I Select Release again")]
        public void WhenISelectReleaseAgain()
        {
            var newSalesOrderPage = new NewSalesOrderPage();
            newSalesOrderPage.ReleaseSalesOrder();
        }

        [When(@"I Select Post from the Home header")]
        public void WhenISelectPostFromTheHomeHeader()
        {
            var newSalesOrderPage = new NewSalesOrderPage();
            newSalesOrderPage.ClickPost();
        }

        [When(@"Select Ship from the pop-up box")]
        public void WhenSelectShipFromThePop_UpBox()
        {
            var newSalesOrderPage = new NewSalesOrderPage();
            newSalesOrderPage.SelectShip();
        }

        [When(@"I Select Shipments from the Home header")]
        public void WhenISelectShipmentsFromTheHomeHeader()
        {
            var newSalesOrderPage = new NewSalesOrderPage();
            newSalesOrderPage.CloseThisWindow();
            BasePage.KillApp();
            BasePage.LaunchApp();
            System.Threading.Thread.Sleep(5000);
            BasePage.SetWindow();
            var navHomePage = new NavHomePage();
            navHomePage.ClickNewSalesOrder();
            var newerSalesOrderPage = new NewSalesOrderPage();
            newerSalesOrderPage.EnterCustomerNumber("048030");
            newerSalesOrderPage.ClickShipment();
            var postedSalesShipmentPage = new PostedSalesShipmentPage();
            postedSalesShipmentPage.ClearFilter();
            var value = _scenarioContext["salesOrderNumber"];
            string salesOrderNumber = value.ToString();
            postedSalesShipmentPage.SearchForTerm(salesOrderNumber);

        }

        [When(@"make a note of the Posted Sales Shipment number")]
        public void WhenMakeANoteOfThePostedSalesShipmentNumber()
        {
            var postedSalesShipmentPage = new PostedSalesShipmentPage();

            _scenarioContext.Add("postedSalesShipmentNumber", postedSalesShipmentPage.GetPostedSalesNumber());
            postedSalesShipmentPage.CloseWindow();
        }

        [When(@"I close the sales order page")]
        public void ICloseTheSalesOrderePage()
        {
            var newSalesOrderPage = new NewSalesOrderPage();
            newSalesOrderPage.CloseWindow();
        }

        [When(@"Search for Integrations Overview in the top right-hand search box")]
        public void WhenSearchForIntegrationsOverviewInTheTopRight_HandSearchBox()
        {
            var navHomePage = new NavHomePage();
            navHomePage.SearchForWord("Integrations Overview");
        }

        [When(@"Highlight the line for WMS Sales Order Line Data")]
        public void WhenHighlightTheLineForWMSSalesOrderLineData()
        {
            var integrationsOverviewPage = new IntegrationsOverviewPage();
            integrationsOverviewPage.FilterByTerm("WMS Sales Order Line data");
            integrationsOverviewPage.HighlightTopLine();
        }

        [When(@"clear the filters on the sales order update entries page if any are applied")]
        public void WhenClearTheFiltersIfAnyAreApplied()
        {
            var viewSalesOrderUpdateEntriesPage = new ViewSalesOrderUpdateEntriesPage();
            viewSalesOrderUpdateEntriesPage.RemoveFilter();
        }

        [When(@"search for the order number previously noted")]
        public void WhenSearchForTheOrderNumberPreviouslyNoted()
        {
            var viewSalesOrderUpdateEntriesPage = new ViewSalesOrderUpdateEntriesPage();
            var value = _scenarioContext["salesOrderNumber"];
            string salesOrderNumber = value.ToString();
            viewSalesOrderUpdateEntriesPage.FilterByTerm(salesOrderNumber);
            viewSalesOrderUpdateEntriesPage.RefreshUntilTestDataAppears();
        }

        [When(@"I go back to the Role Centre Screen")]
        public void WhenIGoBackToTheRoleCentreScreen()
        {
            var navHomePage = new NavHomePage();
            navHomePage.NavigateToRoleCentre();
        }

        [When(@"select Posted Sales Shipments from the left-hand menu")]
        public void SelectPostedSalesShipmentsFromTheLeftHandMenu()
        {
            var navHomePage = new NavHomePage();
            navHomePage.NavigateToPostedSalesShipment();
        }

        [When(@"search for the posted sales shipment number previously noted down")]
        public void WhenSearchForThePostedSalesShipmentNumberPreviouslyNotedDown()
        {
            var homePostedSalesShipmentPage = new HomePostedSalesShipmentPage();
            var value = _scenarioContext["postedSalesShipmentNumber"];
            string postedSalesShipmentNumber = value.ToString();
            homePostedSalesShipmentPage.FilterByTerm(postedSalesShipmentNumber);
            //homePostedSalesShipmentPage.FilterByTerm("PS-0064544");
            homePostedSalesShipmentPage.ClickOnTopRow();
        }



        [When(@"select Sales Return Order to create a collection with customer number ""(.*)""")]
        public void WhenSelectSalesReturnOrderToCreateACollectionWithCustomerNumber(string customerNumber)
        {
            var navHomePage = new NavHomePage();
            navHomePage.ClickNewSalesReturnOrder();
            var salesReturnOrderPage = new SalesReturnOrderPage();
            salesReturnOrderPage.EnterCustomerNumber(customerNumber);
        }

        [When(@"make a note of the SRO number")]
        public void WhenMakeANoteOfTheSRONumber()
        {
            var salesReturnOrderPage = new SalesReturnOrderPage();
           _scenarioContext.Add("returnSalesOrderNumber", salesReturnOrderPage.GetReturnSalesOrderNumber());
        }

        [When(@"Select the dropdown menu for Sales Shipment No\.")]
        public void WhenSelectTheDropdownMenuForSalesShipmentNo_()
        {
            
        }

        [When(@"input the number of parcels as (.*)")]
        public void InputTheNumberOfParcelsAs(int numberOfParcels)
        {
            var salesReturnOrderPage = new SalesReturnOrderPage();
            salesReturnOrderPage.SetNumberOfParcels(numberOfParcels);
        }

        [When(@"select the shipment that lines up with the Posted Sales Shipment number previously noted")]
        public void WhenSelectTheShipmentThatLinesUpWithThePostedSalesShipmentNumberPreviouslyNoted()
        {
            var salesReturnOrderPage = new SalesReturnOrderPage();
            var value = _scenarioContext["postedSalesShipmentNumber"];
            string number = value.ToString();
            salesReturnOrderPage.EnterSalesShipmentNumber(number);
           // salesReturnOrderPage.EnterSalesShipmentNumber("PS-0064544");
        }

        [When(@"I go to the lines that want crediting")]
        public void WhenIGoToTheLinesThatWantCrediting()
        {
            //handled in next step
        }

        [When(@"I for each item I enter the return reason code and quantity and tick box for replacement if necessary")]
        public void WhenIFindItemAndEnterTheReturnReasonCodeAsAndTheQuantityAndTickBoxForReplacementIfNecessary(Table table)
        {
            var salesReturnOrderPage = new SalesReturnOrderPage();
            salesReturnOrderPage.EnterReturnCodeAndQuantityAndTickReplacement(table);
        }

        [When(@"for each item I enter the return reason code and quantity and tick box for collection if necessary")]
        public void WhenIFindItemAndEnterTheReturnReasonCodeAsAndTheQuantityAndTickBoxForCollectionIfNecessary(Table table)
        {
            var salesReturnOrderPage = new SalesReturnOrderPage();
            salesReturnOrderPage.EnterReturnCodeAndQuantityAndTickCollection(table);
        }

        [When(@"I find item and enter the Return Reason code and the quantity")]
        public void WhenIFindItemAndEnterTheReturnReasonCodeAsAndTheQuantity(Table table)
        {
            var salesReturnOrderPage = new SalesReturnOrderPage();
            salesReturnOrderPage.EnterReturnCodeAndQuantity(table);
        }



        [When(@"I Release the sales return order")]
        public void WhenIReleaseTheSalesReturnOrder()
        {
            var salesReturnOrderPage = new SalesReturnOrderPage();
            salesReturnOrderPage.ClickRelease();
        }

        [When(@"I select Replacement Order")]
        public void WhenISelectReplacementOrder()
        {
            var salesReturnOrderPage = new SalesReturnOrderPage();
            salesReturnOrderPage.ClickReplacement();
        }


        [When(@"Highlight the line for WMS Sales Return Order Line Data")]
        public void WhenHighlightTheLineForWMSSalesReturnOrderLineData()
        {
            var integrationsOverviewPage = new IntegrationsOverviewPage();
            integrationsOverviewPage.FilterByTerm("WMS Sales Return Order Line data");
            integrationsOverviewPage.HighlightTopLine();
        }

        [When(@"Select Entries from the Home header")]
        public void WhenSelectEntriesFromTheHomeHeader()
        {
            var integrationsOverviewPage = new IntegrationsOverviewPage();
            integrationsOverviewPage.ClickEntriesButton();
        }

        [When(@"clear any filters on the sales return order line data page")]
        public void ClearAnyFiltersOnTheSalesReturnOrderLineDataPage()
        {
            var viewSalesReturnOrderUpdateEntriesPage = new ViewSalesReturnOrderUpdateEntriesPage();
            viewSalesReturnOrderUpdateEntriesPage.RemoveFilter();
        }

        [When(@"Enter the SRO number that I noted down earlier in the search box")]
        public void WhenEnterTheSRONumberThatINotedDownEarlierInTheSearchBox()
        {
            var viewSalesReturnOrderUpdateEntriesPage = new ViewSalesReturnOrderUpdateEntriesPage();
            var value = _scenarioContext["returnSalesOrderNumber"];
            viewSalesReturnOrderUpdateEntriesPage.FilterByTerm(value.ToString());
            viewSalesReturnOrderUpdateEntriesPage.RefreshUntilTestDataAppears();
        }

        [When(@"I select Purchase Return Order")]
        public void ISelectPurchaseReturnOrder()
        {
            var salesReturnOrderPage = new SalesReturnOrderPage();
            salesReturnOrderPage.ClickPurchaseReturnOrder();
        }

        [Then(@"I should get an error message stating ""(.*)""")]
        public void ThenIShouldGetAnErrorMessageStating(string errorMessage)
        {
            var customBusinessRuleResultsPage = new CustomBusinessRuleResultsPage();
            customBusinessRuleResultsPage.GetRidOfBusinessRules();
            var newSalesOrderPage = new NewSalesOrderPage();
            newSalesOrderPage.ReleaseSalesOrder();
        }


        [Then(@"the status should change to Released in the General section")]
        public void ThenTheStatusShouldChangeToReleasedInTheGeneralSection()
        {
            var newSalesOrderPage = new NewSalesOrderPage();
            newSalesOrderPage.CheckStatus("Released");
        }

        [Then(@"Line Status should change to Released for all Live Items")]
        public void ThenLineStatusShouldChangeToReleasedForAllLiveItems()
        {
            
        }

        [Then(@"Order Type should populate as Stock")]
        public void ThenOrderTypeShouldPopulateAsStock()
        {
            var newSalesOrderPage = new NewSalesOrderPage();
            newSalesOrderPage.CheckOrderType("Stock");
        }

        [Then(@"Order Type should populate as ""(.*)""")]
        public void ThenOrderTypeShouldPopulateAsStock(string itemType)
        {
            var newSalesOrderPage = new NewSalesOrderPage();
            newSalesOrderPage.CheckOrderType(itemType);
        }

        [Then(@"Order Source should populate as Telephone")]
        public void ThenOrderSourceShouldPopulateAsTelephone()
        {
            var newSalesOrderPage = new NewSalesOrderPage();
            newSalesOrderPage.CheckOrderSource("PHONE");
        }

        [Then(@"Delivery Type should populate as STD")]
        public void ThenDeliveryTypeShouldPopulateAsSTD()
        {
            var newSalesOrderPage = new NewSalesOrderPage();
            newSalesOrderPage.CheckDeliveryType("STD");
        }

        [Then(@"Assigned User ID should populate with the user’s name who has created the order")]
        public void ThenAssignedUserIDShouldPopulateWithTheUserSNameWhoHasCreatedTheOrder()
        {
           
        }

        [Then(@"Planned Delivery Date should auto-populate with the correct delivery date")]
        public void ThenPlannedDeliveryDateShouldAuto_PopulateWithTheCorrectDeliveryDate()
        {
            
        }

        [Then(@"sales order Total Excl\. VAT should be showing ""(.*)""")]
        public void ThenTotalExcl_VATShouldBeShowing(string totalExcVat)
        {
            var newSalesOrderPage = new NewSalesOrderPage();
            newSalesOrderPage.CheckTotalExcVAT(totalExcVat);
        }

        [Then(@"sales order Total Inc. VAT should be showing ""(.*)""")]
        public void ThenTotalInc_VATShouldBeShowing(string totalIncVat)
        {
            var newSalesOrderPage = new NewSalesOrderPage();
            newSalesOrderPage.CheckTotalIncVAT(totalIncVat);
        }

        [Then(@"sales order Total VAT should be showing ""(.*)""")]
        public void ThenSalesOrderTotalVATShouldBeShowing(string totalVat)
        {
            var newSalesOrderPage = new NewSalesOrderPage();
            newSalesOrderPage.CheckTotalVAT(totalVat);
        }


        [Then(@"The Line Status will change to Shipped")]
        public void ThenTheLineStatusWillChangeToShipped()
        {

        }
      
        [Then(@"this should show the same number of lines \((.*)\) that have been processed on the sales order that was previously created")]
        public void ThenThisShouldShowTheSameNumberOfLinesThatHaveBeenProcessedOnTheSalesOrderThatWasPreviouslyCreated(int numberOfLines)
        {
            var viewSalesOrderUpdateEntriesPage = new ViewSalesOrderUpdateEntriesPage();
            viewSalesOrderUpdateEntriesPage.CheckNumberOfLines(numberOfLines);
            viewSalesOrderUpdateEntriesPage.CloseThisWindow();
            var integrationsOverviewPage = new IntegrationsOverviewPage();
            integrationsOverviewPage.CloseThisWindow();
        }



        [Then(@"in the general header Customer is populated as ""(.*)""")]
        public void ThenInTheGeneralHeaderCustomerIsPopulatedAs(string customerName)
        {
            var editPostedSalesShipmentPage = new EditPostedSalesShipmentPage();
            editPostedSalesShipmentPage.CheckCustomerName(customerName);
        }

        [Then(@"External document number is populated as ""(.*)""")]
        public void ThenExternalDocumentNumberIsPopulatedAs(string externalDocNumber)
        {
            var editPostedSalesShipmentPage = new EditPostedSalesShipmentPage();
            editPostedSalesShipmentPage.CheckExternalDocNumber(externalDocNumber);
        }

        [Then(@"in the lines section the correct number of lines are showing ""(.*)""")]
        public void ThenInTheLinesSectionTheCorrectNumberOfLinesAreShowing(string p0)
        {
            //handled in next method
        }

        [Then(@"the quantities match what was entered in the sales order")]
        public void ThenTheQuantitiesMatchWhatWasEnteredInTheSalesOrder(Table table)
        {
            var editPostedSalesShipmentPage = new EditPostedSalesShipmentPage();
            editPostedSalesShipmentPage.CheckItemNumberAndQuantity(table);
        }

        [Then(@"the planned delivery date matches the date from the sales order previously created")]
        public void ThenThePlannedDeliveryDateMatchesTheDateFromTheSalesOrderPreviouslyCreated()
        {
            
        }

        [Then(@"in the shipping section the fields; Agent, Agent Service, Package Tracking No\. and Shipment Date should be populated with data")]
        public void ThenInTheShippingSectionTheFieldsAgentAgentServicePackageTrackingNo_AndShipmentDateShouldBePopulatedWithData()
        {
            var editPostedSalesShipmentPage = new EditPostedSalesShipmentPage();
            editPostedSalesShipmentPage.CheckShippingSection();
            editPostedSalesShipmentPage.CloseThisWindow();
        }

        [Then(@"Ensure that the same number of lines has pulled through that was created on the sales order ""(.*)""")]
        public void ThenEnsureThatTheSameNumberOfLinesHasPulledThroughThatWasCreatedOnTheSalesOrder(string p0)
        {
            
        }

        [Then(@"the unit price excl\. vat are the same as when you created the sales order")]
        public void ThenTheUnitPriceExcl_VatAreTheSameAsWhenYouCreatedTheSalesOrder(Table table)
        {
            var salesReturnOrderPage = new SalesReturnOrderPage();
            salesReturnOrderPage.CheckItemNumberAndPrice(table);
        }

        [Then(@"the Credits should then automatically get ticked")]
        public void ThenTheCreditsShouldThenAutomaticallyGetTicked()
        {
            
        }

        [Then(@"Total Excl\. VAT should be showing ""(.*)"" on the sales return order")]
        public void ThenTotalExcl_VATShouldBeShowingOnTheSalesReturnOrder(string totalExcVat)
        {
            var salesReturnOrderPage = new SalesReturnOrderPage();
            salesReturnOrderPage.CheckTotalExcVAT(totalExcVat);
        }

        [Then(@"Total VAT should be showing ""(.*)"" on the sales return order")]
        public void ThenTotalInc_VATShouldBeShowingOnTheSalesReturnOrder(string totalVat)
        {
            var salesReturnOrderPage = new SalesReturnOrderPage();
            salesReturnOrderPage.CheckTotalVAT(totalVat);

        }

        [Then(@"Total Inc\. VAT should be showing ""(.*)"" on the sales return order")]
        public void ThenSalesOrderTotalVATShouldBeShowingOnTheSalesReturnOrder(string totalIncVat)
        {
            var salesReturnOrderPage = new SalesReturnOrderPage();
            salesReturnOrderPage.CheckTotalIncVAT(totalIncVat);
        }


        [Then(@"Status should change to Released in the General section")]
        public void ThenStatusShouldChangeToReleasedInTheGeneralSection()
        {
            var salesReturnOrderPage = new SalesReturnOrderPage();
            salesReturnOrderPage.CheckReleaseStatus("Released");
        }

        [Then(@"Order Type should populate as Stock on the return order")]
        public void ThenOrderTypeShouldPopulateAsStockOnTheReturnOrder()
        {
            var salesReturnOrderPage = new SalesReturnOrderPage();
            salesReturnOrderPage.CheckOrderType("Stock");
        }

        [Then(@"Orig\. Shipment Date should be the same as the Planned Delivery Date from the sales order")]
        public void ThenOrig_ShipmentDateShouldBeTheSameAsThePlannedDeliveryDateFromTheSalesOrder()
        {
            
        }

        [Then(@"the remaining lines should drop from the order leaving (.*) lines")]
        public void ThenTheRemainingLinesShouldDropFromTheOrderLeavingLines(int p0)
        {
            var salesReturnOrderPage = new SalesReturnOrderPage();
            salesReturnOrderPage.CloseWindow();
            
        }

        [Then(@"This should then show the number of lines (.*) that have been processed on the sales return order created")]
        public void ThenThisShouldThenShowTheNumberOfLinesThatHaveBeenProcessedOnTheSalesReturnOrderCreated(int numberOfLines)
        {
            var viewSalesReturnOrderUpdateEntriesPage = new ViewSalesReturnOrderUpdateEntriesPage();
            viewSalesReturnOrderUpdateEntriesPage.CheckNumberOfLines(numberOfLines);
        }

        [When(@"I enter Item number ""(.*)"" and quantity ""(.*)"" in ""(.*)""")]
        public void WhenIEnterItemNumber(string item, string quantity, string rowNo)
        {

            var newSalesOrderPage = new NewSalesOrderPage();
            newSalesOrderPage.CreateLineItemWithRowNumberSO(item, quantity, rowNo);
        }

        [When(@"clear any filters on the sales order line data page")]
        public void ClearAnyFiltersOnTheSalesOrderLineDataPage()
        {
            var salesOrderUpdateEntriesPage = new SalesOrderUpdateEntriesPage();
            salesOrderUpdateEntriesPage.RemoveFilter();
        }

        [When(@"Enter the SO number that I noted down earlier in the search box")]
        public void WhenEnterTheSONumberThatINotedDownEarlierInTheSearchBox()
        {
            var salesOrderUpdateEntriesPage = new SalesOrderUpdateEntriesPage();
            var value = _scenarioContext["SalesOrderNumber"];
            salesOrderUpdateEntriesPage.FilterByTerm(value.ToString());
            //salesOrderUpdateEntriesPage.RefreshUntilTestDataAppears();
        }


        [When(@"I tick substitute")]
        public void WhenITickSubstitute()
        {
            var newSalesOrderPage = new NewSalesOrderPage();
            newSalesOrderPage.SubstitutionChoose();
        }

        [Then(@"Select drop shipment and purchase order")]
        public void ThenSelectDropShipmentAndPurchaseOrder()
        {
            var newSalesOrderPage = new NewSalesOrderPage();
            newSalesOrderPage.OrderDropShipmentPurchaseOrder();

        }

        [When(@"I select Release from the edit purchase Home header")]
        public void WhenSelectFromTheHomeHeader()
        {
            Keyboard.TypeSimultaneously(VirtualKeyShort.CONTROL, VirtualKeyShort.F9);
        }

        [Then(@"Line Status in edit PO should change to Submitted to Vendor")]
        public void ThenLineStatusShouldChangeToSubmittedToVendor()
        {
            var editPurchaseOrderPage = new EditPurchaseOrderPage();
            editPurchaseOrderPage.CheckLineStatus("Submitted to Vendor");

        }

        [Then(@"Total Excl VAT in edit PO should be showing ""(.*)""")]
        public void ThenTotalExcl_VATShouldBeShowingPO(string total)
        {
            var editPurchaseOrderPage = new EditPurchaseOrderPage();
            editPurchaseOrderPage.CheckTotalExcVAT(total);
        }

        [When(@"I close the edit PO screen")]
        public void WhenCloseTheOrderScreen()
        {
            var editPurchaseOrderPage = new EditPurchaseOrderPage();
            editPurchaseOrderPage.ClickCollapseArea();
            editPurchaseOrderPage.ClosePOWindow();
        }

        [Then(@"Total VAT in edit PO should be showing ""(.*)""")]
        public void ThenTotalVATShouldBeShowing(string total)
        {
            var editPurchaseOrderPage = new EditPurchaseOrderPage();
            editPurchaseOrderPage.CheckTotalVAT(total);
        }

        [Then(@"Total Inc VAT in edit PO should be showing ""(.*)""")]
        public void ThenTotalInc_VATShouldBeShowingPO(string total)
        {
            var editPurchaseOrderPage = new EditPurchaseOrderPage();
            editPurchaseOrderPage.CheckTotalIncVAT(total);
        }

        [Then(@"Order Type should populate as Mixed")]
        public void ThenOrderTypeShouldPopulateAsMixed()
        {
            var newSalesOrderPage = new NewSalesOrderPage();
            newSalesOrderPage.CheckOrderType("Mixed");
        }

        [When(@"I move down to Sales Order Vouchers")]
        public void WhenIMoveDownToSalesOrderVouchers()
        {
        }

        [When(@"I click on the dropdown under voucher code and select ""(.*)"" and enter")]
        public void WhenIClickOnTheDropdownUnderVoucherCodeAndSelectAndEnter(string p0)
        {
        }

        [When(@"I search for posted sales invoices")]
        public void WhenISearchForPostedSalesInvoices()
        {
        }

        [When(@"I enter ""(.*)"" and validate")]
        public void WhenIEnterAndValidate(string p0)
        {
        }


        [When(@"I search for posted sales credit memo")]
        public void WhenISearchForPostedSalesCreditMemo()
        {
        }

        [When(@"I add Campaign number ""(.*)""")]
        public void WhenIAddCampaignNumber(string p0)
        {
        }

        [When(@"I highlight each Directs line individually")]
        public void WhenIHighlightEachDirectsLineIndividually()
        {
        }

        [When(@"select Purchase Order")]
        public void WhenSelectPurchaseOrder()
        {
        }

        [When(@"I go to Sales Order")]
        public void WhenIGoToSalesOrder()
        {
        }

        [When(@"make a note of the Purchase Return Order number")]
        public void WhenMakeANoteOfThePurchaseReturnOrderNumber()
        {
        }
    }
}
