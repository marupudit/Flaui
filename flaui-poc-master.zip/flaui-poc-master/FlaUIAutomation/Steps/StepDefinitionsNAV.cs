﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using FlaUIAutomation.Interfaces;
using FlaUIAutomation.PageObjects;
using FlaUIAutomation.PageObjectsWeb;
using FlaUIAutomation.Setup;
using TechTalk.SpecFlow;

namespace FlaUIAutomation.Steps
{
    [Binding]
    public class StepDefinitionsNAV
    {
        private readonly ScenarioContext _scenarioContext;


        public StepDefinitionsNAV(ScenarioContext scenarioContext)
        {
            _scenarioContext = scenarioContext;
        }

        [AfterScenario]
        public void AfterScenario()
        {
            BasePage.KillApp();
        }

        [Given(@"I have generated a sales order with line item for customer ""(.*)""")]
        public void GivenIHaveGeneratedASalesOrderWithLineItemForCustomer(string customerNo, Table table)
        {
            _scenarioContext.Add(
                    "customerid",
                    customerNo
                );

            // Hardcoded for now - But can be smart enough to check headers
            _scenarioContext.Add(
                    "itemType",
                    table.Rows[0][1]
                );

            _scenarioContext.Add(
                    "itemNo",
                    table.Rows[0][1]
                );

            _scenarioContext.Add(
                    "itemQuantity",
                    table.Rows[0][1]
                );

            // REMOVE ME AFTER NAV INTEGRATION
            /*_scenarioContext.Add(
                    "orderid",
                    "SO-00210715"
                );*/

            BasePage.LaunchApp();
            BasePage.SetWindow();

            var navHomePage = new NavHomePage();
            NewSalesOrderPage createSalesOrderPage;
            NoSeriesListPage noSeriesListPage;


            createSalesOrderPage = navHomePage.CreateNewSalesOrder();

            noSeriesListPage = createSalesOrderPage.SetSalesOrderNo();
            createSalesOrderPage = noSeriesListPage.PressOkButton();
            createSalesOrderPage.SetExternalDocumentNumber(Guid.NewGuid().ToString());
            _scenarioContext.Add(
                    "orderid",
                    createSalesOrderPage.RetrieveSalesOrderNumber()
                );


            CommentListPage commentListPage = createSalesOrderPage.EnterCustomerName("000000");
            createSalesOrderPage = commentListPage.PressOkButton();
            createSalesOrderPage.CreateLineItem(table.Rows[0][1], "1");
            createSalesOrderPage.ReleaseSalesOrder();
            CustomBusinessRuleResultsPage customBusinessRuleResultsPage = new CustomBusinessRuleResultsPage();
            customBusinessRuleResultsPage.AssertDuplicateMessageAndClose();
            createSalesOrderPage.AssertStatusIsReleased();

        }

    }
}
