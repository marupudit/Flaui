﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FlaUIAutomation.Interfaces;
using FlaUIAutomation.PageObjectsWeb;
using FlaUIAutomation.Setup;
using NUnit.Framework;
using OpenQA.Selenium;
using TechTalk.SpecFlow;

namespace FlaUIAutomation.Steps
{
    [Binding]
    public class StepDefinitionsWeb
    {
        private ScenarioContext _scenarioContext;
        private GenericPage genericPage;
        private BookingInPage bookingInPage;

        private Browser browser;
        // private readonly IConfig _config;

        public StepDefinitionsWeb(ScenarioContext scenarioContext)
        {
            _scenarioContext = scenarioContext;
            // _config.StartWebDriver();
            // _config.
            
        }

        [AfterScenario]
        public void AfterScenario()
        {
            try
            {
                browser.QuitDriver();
            }
            catch (Exception)
            {
                //pass
            }

        }

        [AfterStep()]
        public void AfterStep()
        {
            if (_scenarioContext.TestError != null)
            {
                string filename = System.Guid.NewGuid().ToString() + ".png";
                filename =
                    "C:\\Dev\\screenshots\\" + // Fix this...
                    filename;

                Screenshot ss = ((ITakesScreenshot)browser.WebDriver).GetScreenshot();
                ss.SaveAsFile(filename); // Fix this... 

                TestContext.AddTestAttachment(filename);
            }

        }

        [When(@"I open a browser")]
        public GenericPage WhenIOpenABrowser()
        {
            System.Threading.Thread.Sleep(30000); //waiting for purchase order to appear in WMS
            browser = new Browser();
            browser.StartWebDriver();
            browser.WebDriver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(15);
            return genericPage = new GenericPage(browser);
        }

        [When(@"log in at ""(.*)""")]
        public void WhenLogInAt(string p0, Table table)
        {
            genericPage.NavigateToAndLogIn();
        }

        [When(@"Select WMS WH(.*)")]
        public void WhenSelectWMSWH(int p0)
        {
            genericPage.ClickOnWMSWH41();
        }

        [When(@"I select booking in with an available timeslot and click on time")]
        public void WhenISelectBookingInWithAnAvailableTimeslotAndClickOnTime()
        {
            bookingInPage = new BookingInPage(browser); 
            genericPage.GoToBookingInPage();
            bookingInPage.ClickOnATime();

        }

        [When(@"search for and click on the vendor number ""(.*)""")]
        public void WhenSearchForAndClickOnTheVendorNumber(string vendorName)
        {
            bookingInPage = new BookingInPage(browser);
            bookingInPage.SearchForAVendor(vendorName);
            System.Threading.Thread.Sleep(4000);
            bookingInPage.ClickOnAVendor(vendorName);
            System.Threading.Thread.Sleep(4000);
        }

        [When(@"search for the YPO order number previously noted")]
        public void WhenSearchForTheYPOOrderNumberPreviouslyNoted()
        {
            string purchaseOrderNumber; // = "PO-0070791";
            _scenarioContext.TryGetValue("purchaseOrderNumber", out purchaseOrderNumber);
            bookingInPage = new BookingInPage(browser);
            bookingInPage.SearchForAnOrder(purchaseOrderNumber);
            System.Threading.Thread.Sleep(4000);
            bookingInPage.SelectAnOrder(purchaseOrderNumber);
            System.Threading.Thread.Sleep(4000);
        }

        [When(@"add ""(.*)"" pallet then update")]
        public void WhenAddPalletThenUpdate(string numberOfPallets)
        {
            bookingInPage = new BookingInPage(browser);
            bookingInPage.ClickAddTimeSlotButton();
            System.Threading.Thread.Sleep(4000);
            bookingInPage.EnterNumberOfPallets(numberOfPallets);
            System.Threading.Thread.Sleep(4000);
            bookingInPage.ClickUpdate();
            System.Threading.Thread.Sleep(4000);
        }

        [When(@"on the next screen press D on the line of the timeslot previously selected")]
        public void WhenOnTheNextScreenSelectTheLineOfTheTimeslotPreviouslySelected()
        {
            bookingInPage = new BookingInPage(browser);
            bookingInPage.ClickDButton();
        }


        [When(@"enter ""(.*)"" for pallets delivered then update")]
        public void WhenEnterForPalletsDeliveredThenUpdate(string numberOfPallets)
        {
            bookingInPage = new BookingInPage(browser);
            System.Threading.Thread.Sleep(4000);
            bookingInPage.EnterActualNumberOfPallets(numberOfPallets);
        }

        [When(@"on the same line as before select R")]
        public void WhenOnTheSameLineAsBeforeSelect()
        {
            bookingInPage = new BookingInPage(browser);
            System.Threading.Thread.Sleep(4000);
            bookingInPage.ClickRButton();

        }

        [When(@"search for and select the YPO order number")]
        public void WhenSearchForAndSelectTheYPOOrderNumber()
        {
            string purchaseOrderNumber; //= "PO-0070791"; 
            _scenarioContext.TryGetValue("purchaseOrderNumber", out purchaseOrderNumber);
            bookingInPage = new BookingInPage(browser);
            bookingInPage.SearchForAnOrder(purchaseOrderNumber);
            System.Threading.Thread.Sleep(4000);
            bookingInPage.ClickOnPurchaseOrderRow(purchaseOrderNumber);
        }

        [When(@"select the first line and enter the details")]
        public void WhenSelectTheFirstLineAndEnterTheDetails(Table table)
        {
            
            bookingInPage = new BookingInPage(browser);
            bookingInPage.ClickOnPurchaseOrderLine("1");
            bookingInPage.EnterVendorDelNoAndReceivedQty("001", "500");
            bookingInPage.EnterPalletNumberQtyAndBatchNo("1", "500", "1");
            bookingInPage.ClickUpdate();

        }

        [When(@"select the second line and enter the details")]
        public void WhenSelectTheSecondLineAndEnterTheDetails(Table table)
        {
            bookingInPage = new BookingInPage(browser);
            bookingInPage.ClickOnPurchaseOrderLine("2");
            bookingInPage.SelectDeliveryStatusDropDownOption("Damaged");
            bookingInPage.EnterVendorDelNoAndReceivedQty("001", "500");
            bookingInPage.SetBestBeforeDate("27/12/2021");
            bookingInPage.EnterPalletNumberQtyAndBatchNo("1", "500", "1");
            bookingInPage.ClickUpdate();

        }

        [When(@"select the third line and enter the details")]
        public void WhenSelectTheThirdLineAndEnterTheDetails(Table table)
        {
            bookingInPage = new BookingInPage(browser);
            bookingInPage.ClickOnPurchaseOrderLine("3");
            bookingInPage.SelectDeliveryStatusDropDownOption("Damaged");
            bookingInPage.EnterVendorDelNoAndReceivedQty("001", "500");
            bookingInPage.SetBestBeforeDate("27/12/2021");
            bookingInPage.EnterPalletNumberQtyAndBatchNo("1", "500", "1");
            bookingInPage.ClickUpdate();
        }

        [When(@"select the fourth line and enter the details")]
        public void WhenSelectTheFourthLineAndEnterTheDetails(Table table)
        {
            bookingInPage = new BookingInPage(browser);
            bookingInPage.ClickOnPurchaseOrderLine("4");
            bookingInPage.SelectDeliveryStatusDropDownOption("Damaged");
            bookingInPage.EnterVendorDelNoAndReceivedQty("001", "500");
            bookingInPage.SetBestBeforeDate("27/12/2021");
            bookingInPage.EnterPalletNumberQtyAndBatchNo("1", "500", "1");
            bookingInPage.ClickUpdate();
        }

        [When(@"select the fifth line and enter the details")]
        public void WhenSelectTheFifthLineAndEnterTheDetails(Table table)
        {
            bookingInPage = new BookingInPage(browser);
            bookingInPage.ClickOnPurchaseOrderLine("2");
            bookingInPage.SelectDeliveryStatusDropDownOption("Damaged");
            bookingInPage.EnterVendorDelNoAndReceivedQty("001", "500");
            bookingInPage.SetBestBeforeDate("27/12/2021");
            bookingInPage.EnterPalletNumberQtyAndBatchNo("1", "500", "1");
            bookingInPage.ClickUpdate();
        }

        [When(@"press back twice")]
        public void WhenPressBackTwice()
        {
            bookingInPage = new BookingInPage(browser);
            bookingInPage.ClickBackButton();
            System.Threading.Thread.Sleep(4000);
            bookingInPage.ClickBackButton();

        }

        [When(@"On the same line as before select the Folio number")]
        public void WhenOnTheSameLineAsBeforeSelectTheFolioNumber()
        {
            bookingInPage = new BookingInPage(browser);
            bookingInPage.ClickFolioNumber();
        }

        [Then(@"the number should change from orange to green")]
        public void ThenTheNumberShouldChangeFromOrangeToGreen()
        {
            
        }



        [Given(@"I am on the WMS Home Page")]
        public void GivenIAmOnTheWMSHomePage()
        {
            browser = new Browser();
            browser.StartWebDriver();
            browser.WebDriver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(15);
            genericPage = new GenericPage(browser);
            genericPage.NavigateToAndLogIn();
            genericPage.ClickOnWMSWH41();
        }

        [When(@"I navigate to the Item Card Page")]
        public void WhenINavigateToTheItemCardPage()
        {
            genericPage.GoToItemCardPage();
        }

        [When(@"select ""(.*)"" from the ""(.*)"" dropdown")]
        public void WhenSelectFromTheDropdown(string dropdownValue, string dropdownName)
        {
            genericPage.SelectFromDropdown(dropdownValue, dropdownName);
        }

        [When(@"search for customer ""(.*)""")]
        public void WhenSearchForCustomer(int p0)
        {
            genericPage.SwitchToTabByName("WMS Customer Information");
            genericPage.SearchForCustomerId(p0.ToString());
        }

        [Then(@"I will see that the customer name is ""(.*)""")]
        public void ThenIWillSeeThatTheCustomerNameIs(string customerName)
        {
            genericPage.AssertCustomerNameIsCorrectOnCustomerInformationPage(customerName);
        }

        [When(@"I go to the Sales Order View within WMS for the generated sales order")]
        public void WhenIGoToTheSalesOrderViewWithinWMSForTheGeneratedSalesOrder()
        {
            genericPage.NavigateToAndLogIn();
            genericPage.ClickOnWMSWH41();
            genericPage.GoToItemCardPage();
            genericPage.SwitchToTabByName("WMS Item Card 41");
            genericPage.SelectFromDropdown("Sales Order View", "Tools");

            string customerid;
            string orderid;

            _scenarioContext.TryGetValue("customerid", out customerid);
            _scenarioContext.TryGetValue("orderid", out orderid);

            genericPage.SwitchToTabByName("WMS Sales Order View");

            genericPage.SearchForCustomerId(customerid);

            genericPage.OpenSearchResultByOrderKey(orderid);


        }

        [Then(@"I see my line item details are correct")]
        public void ThenISeeMyLineItemDetailsAreCorrect(Table table)
        {
            genericPage.AssertSalesOrderViewLineItem(table);
        }

    }
}

