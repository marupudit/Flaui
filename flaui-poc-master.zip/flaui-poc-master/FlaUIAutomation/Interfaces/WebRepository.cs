﻿using FlaUIAutomation.PageObjectsWeb;

namespace FlaUIAutomation.Interfaces
{
    public interface IRepository
    {
        GenericPage GenericPage { get; set; }
        
    }
}