﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using FlaUIAutomation.Interfaces;

namespace FlaUIAutomation.Setup
{
    public class Browser : IConfig
    {
        public IWebDriver WebDriver { get; set; }

        public void QuitDriver()
        {
            WebDriver?.Quit();
        }

        public void StartWebDriver()
        {
            WebDriver = GetChromeDriverOptions();
        }

        private IWebDriver GetChromeDriverOptions()
        {
            var chromeService = ChromeDriverService.CreateDefaultService();
            chromeService.HideCommandPromptWindow = true;
            return new ChromeDriver(chromeService, SetChromeOptions());
        }

        private ChromeOptions SetChromeOptions()
        {
            var options = new ChromeOptions();
            options.AddArguments("--start-maximized");
            return options;
        }
    }
}
